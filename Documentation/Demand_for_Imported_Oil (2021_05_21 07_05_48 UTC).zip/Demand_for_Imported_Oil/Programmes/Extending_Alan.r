##    Programme:  Demand_for_Imported_Oil.r
##
##    Objective:  This programme replicates the work of Jaforullah and King in their article
##                "The Demand for Imported Oil: New Zealand's Post-Deregulation Experience"
##                published in New Zealand Economic Papers, 2018, Vol 52, No.1, page 40-52
##                available here:
##                   https://doi.org/10.1080/00779954.2016.1207199
##
##
##      Author:   James Hogan, 26 January 2018
##
 rm(list=ls(all=TRUE))
   
   ##
   ##    Read in some functionality, set the working directory and 
   ##       connect to the database
   ##
      library(RODBC)
      library(strucchange)
      library(lmtest)
      library(scales)
      library(dynlm)
      library(systemfit)
      library(ggplot2)
      library(sqldf)
      library(plyr)
      library(stringr)
      library(reshape2)
      library(tseries)
      library(cluster)
      library(lubridate)
      library(nlme)
      library(mbie)
      library(mbieDBmisc)
      library(plm)
      library(splines)
      library(calibrate)
      library(systemfit)
      library(micEconCES)      
      library(forecast)
      library(urca)
      library(vars)
      
      setwd("P:/R&N/Networks/Energy Information & Modelling/energy_modelling/Demand_for_Imported_Oil")
      ##
      ##    Load the regression dataframe
      ##
         load("Output/Regression_Dataset.rda")
         Regression_Dataset$Log_Imports    <- log(Regression_Dataset$Imports)
         Regression_Dataset$Log_Real_GDP   <- log(Regression_Dataset$Value)
         Regression_Dataset$Log_Real_Prices <- log(Regression_Dataset$Real_Prices)
      ##
      ##
      ##
         Researcher_Data <- read.csv(file = "Source_Data/Researcher_Data.csv")
      
      ##
      ##    Do some cointergration
      ##
         Researcher_Data
         jotest=ca.jo(data.frame(Researcher_Data$lnQ,
                            Researcher_Data$lnYR,
                            Researcher_Data$lnRP), 
                            type="trace", 
                            K=4, 
                            ecdet="const", 
                            spec="longrun")
         summary(jotest)
      testStatistics <- jotest@teststat
      criticalValues <- jotest@criticalValues       













      
         
      ##
      ##    Ok, I've gotten Alan's results using his data.  Where has my data gone wrong?
      ##
         Researcher_Data$TimePeriod <- as.Date(ifelse(str_sub(Researcher_Data$Period, start=6, end=6) == 1, paste(str_sub(Researcher_Data$Period, start=1, end=4), "03/01", sep="/"),
                                        ifelse(str_sub(Researcher_Data$Period, start=6, end=6) == 2, paste(str_sub(Researcher_Data$Period, start=1, end=4), "06/01", sep="/"),
                                          ifelse(str_sub(Researcher_Data$Period, start=6, end=6) == 3, paste(str_sub(Researcher_Data$Period, start=1, end=4), "09/01", sep="/"),
                                                                                            paste(str_sub(Researcher_Data$Period, start=1, end=4), "12/01", sep="/")))), "%Y/%m/%d")
         month(Researcher_Data$TimePeriod) <- month(Researcher_Data$TimePeriod) + 1
         day(Researcher_Data$TimePeriod) <- day(Researcher_Data$TimePeriod) - 1
      ##
      ##    Merge together and graph
      ##
         Combined_Data <- merge(Researcher_Data,
                             Regression_Dataset,
                             by = c("TimePeriod"),
                             all = TRUE)
         Plot_Me <- melt(Combined_Data,
                      id.vars = c("TimePeriod"),
                      measure.var = c("lnQ", "lnYR", "lnRP", "Log_Imports", "Log_Real_GDP", "Log_Real_Prices"))
         Plot_Me$Source <- ifelse(Plot_Me$variable %in% c("lnQ", "lnYR", "lnRP"), "Uni of Otago", "MBIE")
         Plot_Me$Measure <- ifelse(Plot_Me$variable %in% c("lnQ", "Log_Imports"), "Imports", 
                           ifelse(Plot_Me$variable %in% c("lnYR", "Log_Real_GDP"), "Real GDP",
                              "Real Prices"))
                                        
     png("Output/Comparison between Datasets_version2.png",units = "cm", width = 24.8, height = 13.47,res=600)
      ggplot(Plot_Me, 
             aes(x=TimePeriod, y= value, colour = Source)) +
             geom_point(size = .5) +
             geom_line() +
             labs(title = "Demand for Imported Oil - Source Data Comparison\n") +
             xlab("Time Period\n") +
             ylab("Log Values\n") +
             scale_colour_manual(values = mbie.cols()) +
             facet_grid(Measure ~., scales="free") +
              theme(axis.title.x = element_text(angle=00, vjust=0.5, size=6),
                   axis.title.y = element_text(angle=90, vjust=0.5, size=6),
                   axis.text.x  = element_text(angle=90, vjust=0.5, size=5),
                   axis.text.y  = element_text(angle=00, vjust=0.5, size=5.5),
                   strip.text   = element_text(angle=90, vjust=0.5, size=6),
                   legend.title = element_text(angle=00, vjust=0.5, size=6),
                   legend.text  = element_text(angle=00, vjust=0.5, size=6),
                   #plot.background= element_rect(fill="red"),
                   legend.margin  = unit(-0.6,"cm"),
                   plot.margin=unit(c(1,1,1,1),"mm"),
                 legend.position  = "bottom") 
     dev.off()                                          
   ##
   ##    Estimate the long run component
   ## 
      jotest=ca.jo(data.frame(Regression_Dataset$Log_Imports,
                         Regression_Dataset$Log_Real_GDP,
                         Regression_Dataset$Log_Real_Prices), 
                         type="trace", 
                         K=4, 
                         ecdet="const", 
                         spec="longrun")
      summary(jotest)
      testStatistics <- jotest@teststat
      criticalValues <- jotest@criticalValues

   ##
   ##    Estimate the dynamic component
   ## 
      dynamic_bit <- cajools(jotest)
      summary(dynamic_bit)
      
   ##
   ##    Estimate the dynamic component
   ## 
      dynamic_bit <- cajools(jotest,
                         reg.number=NULL)
      summary(dynamic_bit)
      
      dynamic_bit <- alphaols(jotest)
      summary(dynamic_bit)

         