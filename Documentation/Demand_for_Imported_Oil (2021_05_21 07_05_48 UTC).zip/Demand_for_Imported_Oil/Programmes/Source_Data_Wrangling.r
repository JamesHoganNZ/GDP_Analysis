##    Programme:  Demand_for_Imported_Oil.r
##
##    Objective:  This programme replicates the work of Jaforullah and King in their article
##                "The Demand for Imported Oil: New Zealand's Post-Deregulation Experience"
##                published in New Zealand Economic Papers, 2018, Vol 52, No.1, page 40-52
##                available here:
##                   https://doi.org/10.1080/00779954.2016.1207199
##
##
##      Author:   James Hogan, 26 January 2018
##
   rm(list=setdiff(ls(), c("MBIELibPaths", "library")))

   ##
   ##    Clear the decks and load up some functionality
   ##
      library(RODBC)
      library(mbie)
      library(mbieDBmisc)
      library(ggplot2)
      library(sqldf)
      library(plyr)
      library(stringr)
      library(reshape2)
      library(lubridate)
      library(calibrate)
      library(Hmisc)
      library(XLConnect)
      
      library(scales)
      library(RCurl)
      library(XML)   
      TRED <- odbcConnect("TRED_Prod")
      
      setwd("P:/R&N/Networks/Energy Information & Modelling/energy_modelling/Demand_for_Imported_Oil")
      database_tables <- "P:/R&N/Networks/Energy Information & Modelling/energy_data/core_systems/petroleum/data_intermediate/database_tables"
      
   ##
   ##    Grab some TRED GDP data
   ##
#      Real_GDP  <- ImportTS2(TRED, "SNE - Series, GDP(P), Chain volume, Actual, ANZSIC06 industry groups (Qrtly-Mar/Jun/Sep/Dec)", silent = TRUE)
#      Real_GDP <- Real_GDP[Real_GDP$CV2 == "Total All Industries",]
      Real_GDP  <- ImportTS2(TRED, "SNE - Series, GDP(P), Chain volume, Seasonally adjusted, Total (Qrtly-Mar/Jun/Sep/Dec)", silent = TRUE)
      
      ##
      ##  Jaforullah and Alan write:
      ##
      ##  10. Statistics New Zealand's official measure of the CPI for ‘all groups less petrol’ is only available back to 1999Q2. 
      ##      However, as the ‘petrol’ CPI series and the weight assigned to it in the ‘all groups’ CPI series (i.e. 3.74% for 
      ##      the period 1988 to 1993 and 3.80% for the period 1993–1999) are available, we are able to infer the values of the 
      ##      ‘all groups less petrol’ series for the remainder of our sample period.      
      ##
      ##  So, I've got to derive this before we can use it.  I'll pull down the All Groups CPI, then I'll pull down the detailed
      ##      petrol CPI.  Then 0.0374 * Petrol_Price + (1-0.0374) * ALL_OTHER_PRICES = ALL_Groups_CPI and we can reverse the 
      ##      timeseries out.
      
      CPI_Detail <- ImportTS2(TRED, "CPI Level 3 Classes for New Zealand (Qrtly-Mar/Jun/Sep/Dec)", silent = TRUE)
      CPI_Less  <- ImportTS2(TRED, "CPI Non-standard All Groups Less/Plus Selected Groupings for New Zealand (Qrtly-Mar/Jun/Sep/Dec)", silent = TRUE)
      CPI_All   <- ImportTS2(TRED, "CPI All Groups for New Zealand (Qrtly-Mar/Jun/Sep/Dec)", silent = TRUE)
      PPI_All   <- ImportTS2(TRED, "Outputs (ANZSIC06) - NZSIOC level 1, Base: Dec. 2010 quarter (=1000) (Qrtly-Mar/Jun/Sep/Dec)", silent = TRUE)
     
      CPI_Detail <- CPI_Detail[CPI_Detail$CV1 == "Petrol",]
      PPI_All <- PPI_All[PPI_All$CV1 == "All Industries",]
      
   ##
   ##    Make the price measure - first off, grab and manipulate the SNZ data
   ##
   ##    Jaforullah and Alan then deflate the petrol subgroup by the ‘all groups less petrol’ variable to
   ##       create a relative price measure... this is a new technique for me, and I like it!
   ##
      CPI_Combined <- merge(CPI_All,
                         CPI_Detail[CPI_Detail$CV1 == "Petrol",],
                         by = c("TimePeriod"),
                         all = TRUE)
      CPI_Combined$Petrol_Weighing <- as.numeric(ifelse(year(CPI_Combined$TimePeriod) < 1993, 0.0374, 0.0380))
      CPI_Combined$All_Other_Prices <- with(CPI_Combined, (Value.x - (Petrol_Weighing * Value.y))/(1-Petrol_Weighing))
      ##
      ##    Stick this on the CPI_Less data frame
      ##
      CPI_Less <- merge(CPI_Less[CPI_Less$CV1 == "All groups less petrol class",],
                      CPI_Combined[, c("TimePeriod", "All_Other_Prices")],
                      by = c("TimePeriod"),
                      all = TRUE)      
      CPI_Less$Sythnetic_CPI_Series <- as.numeric(ifelse(is.na(CPI_Less$Value), CPI_Less$All_Other_Prices, CPI_Less$Value))
      plot(CPI_Less$Value, CPI_Less$All_Other_Prices)
      
   ##
   ##    Secondly, grab our data sets
   ##
   ##
      ##
      ##    Grab out prices from the net.  These are expressed as dollars per gigajoule.  Imports are measured in Petajoules, 
      ##       so need to deflate prices by 1000000 to make them dollars per petajoule.
      ##
      ##    Secondly, J&A write: 
      ##       11. According to data from the Ministry of Business, Innovation and Employment, petrol and diesel account 
      ##       for approximately 45% and 37%, respectively, of all petroleum products consumed (in petajoule terms) within 
      ##       New Zealand over the sample period. Hence, the weight assigned to the petrol and diesel price series is 
      ##       approximately 0.54 and 0.46, respectively.
      ##
      ##    So I need to weight the petrol and diesel prices to create a composite price, which then gets deflated by the PPI outputs
      ##
         download.file(url = "http://www.mbie.govt.nz/info-services/sectors-industries/energy/energy-data-modelling/statistics/documents-image-library/prices.xlsx", 
                       mode = "wb",
                       destfile = "Source_Data/Prices.xlsx")               
         Workbook   <- loadWorkbook("Source_Data/Prices.xlsx")
         All_Sheets <- data.frame(TabName = as.character(t(t(getSheets(Workbook)))))
        
         for(i in 1:nrow(All_Sheets))
         { assign(paste0(str_replace_all(All_Sheets$TabName[i], " ","_")),
                 readWorksheet(Workbook, sheet = as.character(All_Sheets$TabName[i]), colTypes = c('character')))
         }
         Prices <- `Quarterly_NZD_per_GJ_(nominal)`
         Prices <- Prices[Prices$Col1 %in% c("Quarter", "Petrol1", "Retail"),]
      
         Prices <- melt(Prices,
                     id.vars = c("Col1"))
         Prices <- dcast(Prices,
                variable ~ Col1,
                value.var = c("value"))
         Prices$TimePeriod <- as.Date(Prices$Quarter)
         
         Prices$Petrol <- as.numeric(Prices$Petrol1)/1000000
         Prices$Diesel <- as.numeric(Prices$Retail)/1000000
         ##
         ##    PPI is month end, and our data is month start... make ours month end and 
         ##    Merge with the PPI outputs dataframe
         ##
         month(Prices$TimePeriod) <- month(Prices$TimePeriod) + 1
         day(Prices$TimePeriod) <- day(Prices$TimePeriod) - 1
         Prices <- Prices[!is.na(Prices$TimePeriod), c("TimePeriod", "Petrol", "Diesel")] 
         
         Prices <- merge(Prices,
                       PPI_All[, c("TimePeriod", "Value")],
                       by = c("TimePeriod"),
                       all = TRUE)  
         names(Prices)[names(Prices) == "Value"] <- "PPI"
         
         Prices <- merge(Prices,
                       CPI_Less[, c("TimePeriod", "Sythnetic_CPI_Series")],
                       by = c("TimePeriod"),
                       all = TRUE)  
         ##
         ##    Express the synthetic CPI on a 2010-12-31 period
         ##
         Prices$Sythnetic_CPI_Series <- (Prices$Sythnetic_CPI_Series / Prices$Sythnetic_CPI_Series[Prices$TimePeriod == '2010-12-31'] )*1000
         ##
         ##    Generate "real prices" as the weighted mean of deflated things
         ##
         Prices$Real_Prices <- with(Prices, (0.46 * (Diesel /  PPI)) + (0.54 *(Petrol / Sythnetic_CPI_Series)))
         Prices$Real_Prices <- (Prices$Real_Prices / Prices$Real_Prices[Prices$TimePeriod == '2010-12-31'])*100
      ##
      ##    Grab Jeff's Oild dataset
      ##
         # load(file = file.path("P:/R&N/Networks/Energy Information & Modelling/energy_data/core_systems/petroleum/data_intermediate/database_tables", "dbo_oil_imports.rda"))
         # load(file = file.path("P:/R&N/Networks/Energy Information & Modelling/energy_data/core_systems/petroleum/data_intermediate/database_tables", "dbo_og_codes.rda"))

         # # units in database are in tonnes so we need to convert to PJ by 
         # # multiplying by MJ/kg and then dividing by 1,000,000

         # Oil <- dbo_oil_imports %>%
           # left_join(dbo_og_codes, "og_code") %>%
           # filter(cr_type == "RF") %>%
           # group_by(yr, mth) %>%
           # summarise(pj = sum(oi_amt*gro_mjpkg)/1000000)
           
        # Oil <- merge(dbo_oil_imports,
                    # dbo_og_codes,
                    # by = c("og_code"),
                    # all.x = TRUE)
        # Oil$TimePeriod <- as.Date(ifelse(Oil$mth %in% c(1,2,3), paste(Oil$yr,"03","01", sep="-"),
                        # ifelse(Oil$mth %in% c(4,5,6), paste(Oil$yr,"06","01", sep="-"),
                          # ifelse(Oil$mth %in% c(7,8,9), paste(Oil$yr,"09","01", sep="-"),
                            # paste(Oil$yr,"12","01", sep="-")))), "%Y-%m-%d")
        # Oil <- with(Oil[Oil$cr_type == "RF",],
                   # aggregate(list(pj = oi_amt*gro_mjpkg /1000000),
                             # list(TimePeriod = TimePeriod),
                             # sum, 
                             # na.rm = FALSE)
                             # )
         # month(Oil$TimePeriod) <- month(Oil$TimePeriod) + 1
         # day(Oil$TimePeriod) <- day(Oil$TimePeriod) - 1
         
      ##
      ##    I didn't like Jeff's code - it wasn't giving the same volumes as the researchers
      ##
      ##     FUCKING EXCEL!!!  Imports are a formula which isn't read in correctly into R.  I've had to copy / paste as value
      ##
       #  download.file(url = "http://www.mbie.govt.nz/info-services/sectors-industries/energy/energy-data-modelling/statistics/documents-image-library/oil.xlsx", 
       #                mode = "wb",
       #                destfile = "Source_Data/Oil.xlsx")               
         Workbook   <- loadWorkbook("Source_Data/Oil.xlsx")
         All_Sheets <- data.frame(TabName = as.character(t(t(getSheets(Workbook)))))
        
         for(i in 1:nrow(All_Sheets))
         { assign(paste0(str_replace_all(All_Sheets$TabName[i], " ","_")),
                 readWorksheet(Workbook, sheet = as.character(All_Sheets$TabName[i]), colTypes = c('character')))
         }
         Oil <- `Quarterly_PJ`
         Oil <- Oil[Oil$Col1 %in% c("Quarters", "Imports"),]
      
         Oil <- melt(Oil,
                   id.vars = c("Col1"))
         Oil <- dcast(Oil,
                   variable ~ Col1,
                   value.var = c("value"))
         Oil$TimePeriod <- as.Date(Oil$Quarter)
         month(Oil$TimePeriod) <- month(Oil$TimePeriod) + 1
         day(Oil$TimePeriod) <- day(Oil$TimePeriod) - 1
         Oil$Imports <- as.numeric(Oil$Imports)
         Oil <- Oil[, c("TimePeriod", "Imports")]
      ##
      ##    Make the regression dataset
      ##
         Regression_Dataset <- merge(Oil,
                                 Real_GDP[, c("TimePeriod", "Value")],
                                 by = c("TimePeriod"),
                                 All = TRUE)
         Regression_Dataset <- merge(Regression_Dataset,
                                 Prices[, c("Real_Prices", "TimePeriod")],
                                 by = c("TimePeriod"),
                                 All = TRUE)
         Regression_Dataset <- Regression_Dataset[year(Regression_Dataset$TimePeriod) > 1988,]
         save(Regression_Dataset, file="Output/Regression_Dataset.rda")

##
##   And we're done here.
##
     
     