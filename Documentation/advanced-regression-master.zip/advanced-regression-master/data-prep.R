library(readr)
library(dplyr)
library(testthat)
?read_fixed


#-----------Poisson examples from Stanford------------------
download.file("http://data.princeton.edu/wws509/datasets/copen.dat",
              destfile = "copen.dat")

# note.  Edited copen.data by hand because about halfway down the fixed widths change
# and need to insert to spaces each line
copen <- read_fwf("copen.dat", col_positions = fwf_widths(c(3, 11, 10, 8, 12, 3)))[ , -1]
names(copen) <- copen[1, ]
copen <- copen[-1, ]
copen <- copen %>%  filter(!is.na(housing)) %>%
  mutate(n = as.numeric(n))
expect_equal(length(table(copen$satisfaction)), 3)
expect_equal(length(table(copen$influence)), 3)
save(copen, file = "data/copen.rda")


# from McCullagh and Nelder example
download.file("http://data.princeton.edu/wws509/datasets/ships.dat",
              destfile = "ships.dat")

ships <- read_fwf("ships.dat", col_positions = fwf_widths(c(3, 5, 12, 10, 7, 8)))[ , -1]
names(ships) <- ships[1, ]
ships <- ships[-1, ]

ships <- ships %>% 
  filter(!is.na(damage)) %>%
  mutate(damage = as.numeric(damage),
         months = as.numeric(months))
save(ships, file = "data/ships.rda")

unlink("copen.dat")
unlink("ships.dat")


#-------------Example 10.2 from Harrell, Regresion Modeling Strategies------------------

females <- data.frame(age = c(37,39,39,42,47,48,48,52,53,55,56,57,58,58,60,64,65,68,68,70),
                      response = c(0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,1,1,1,1), 
                      sex = "female", stringsAsFactors = FALSE)
males <- data.frame(age = c(34,38,40,40,41,43,43,43,44,46,47,48,48,50,50,52,55,60,61,61),
                    response = c(1,1,0,0,0,1,1,1,0,0,1,1,1,0,1,1,1,1,1,1),
                    sex = "male", stringsAsFactors = FALSE)

eg10.2 <- rbind(females, males)
save(eg10.2, file = "data/eg10.2.rda")


#---------freakonemetrics-------
source("http://freakonometrics.free.fr/probit.R")
freak <- data.frame(Y, X1, X2)
head(freak)
save(freak, file = "data/freak.rda")


#--------census data
library(nzcensus)
save(AreaUnits2013, file = "data/AreaUnits2013.rda")
save(TA2013, file = "data/TA2013.rda")
