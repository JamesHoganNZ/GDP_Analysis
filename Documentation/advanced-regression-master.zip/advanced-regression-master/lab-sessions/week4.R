# MAKE A COPY OF THIS SCRIPT IN YOUR P:/r/%USERNAME% FOLDER 
# - DON'T WORK ON IT DIRECTLY BECAUSE IT IS SUBJECT TO
# BEING OVER-WRITTEN WITHOUT NOTICE!

# This session works with elastic net regularisation

library(tidyverse)
library(mice)
library(testthat)
library(boot)
library(glmnet)

user <- Sys.info()['login']
setwd(paste0("P:/R/", user, "/advanced-regression"))

load("AreaUnits2013.rda")   # copied from {nzcensus} package


au_orig <- AreaUnits2013 %>%
  select(-AU2014, -AU_NAM, -NZTM2000Easting, -NZTM2000Northing) %>%
  filter(!is.na(MedianIncome2013)) # knock out where y is missing
names(au_orig) <- gsub("2013", "", names(au_orig))

y_orig <- au_orig$MedianIncome

# single imputation of missing variables.  Note that we are inlcuding the y
# in the imputation models; process recommended by harrel
au_imputed <- mice::complete(mice(au_orig, m = 1), 1)

X <- as.matrix(au_imputed[ , names(au_imputed) != "MedianIncome"])
# note.  Why "as.matrix"?  try it without and see what happens with glmnet.


#=============lasso============
mod_lasso <- cv.glmnet(x = X, y = y_orig)

# what does all this mean:
mod_lasso

# what is this?
mod_lasso$lambda.min
plot(mod_lasso)


#=============ridge regression============
mod_ridge <- cv.glmnet(x = X, y = y_orig, alpha = 0)

# compare to before
mod_ridge

# what is this?
mod_ridge$lambda.min
plot(mod_ridge)

# Compare:
cbind(coef(mod_ridge), coef(mod_lasso))



# your turn - fit a model with lm or glm *without* elastic net regularisation, and add its coefficients 
# as a third column to the above comparison of the ridge regression and lasso coefficients.


# your turn - from the help file, which part of the list returned by cv.glmnet is the 
# mean cross-validated error.  What is it for the ridge regression, and what for the lasso?
# try the same model above with different values of alpha.  What value of alpha works best?
# [You could do this by writing a loop, or by just copying and pasting.]



# your turn
# With the state.x77 matrix, store the murder rate as y.  Use all the other variables in that matrix as 
# explanatory variables in a glmnet model.  Try with a gaussian response (the default) and a Poisson response.
# Try with a lasso and with ridge regression, and with alpha = 0.5.
# Compare the predicted values of the different models (hint: something like predict(mymodel, newx = X))



# your turn - more advanced - use bootstrap validation on glmnet used with either of the datasets above
