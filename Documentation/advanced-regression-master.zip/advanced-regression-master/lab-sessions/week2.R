# MAKE A COPY OF THIS SCRIPT IN YOUR P:/r/%USERNAME% FOLDER 
# - DON'T WORK ON IT DIRECTLY BECAUSE IT IS SUBJECT TO
# BEING OVER-WRITTEN WITHOUT NOTICE!

# This session works with generalized additive models, using the mgcv package

library(tidyverse)
library(mgcv)
library(testthat)
library(boot)

user <- Sys.info()['login']
setwd(paste0("P:/R/", user, "/advanced-regression"))

load("TA2013.rda")   # {nzcensus}



#=====================generalized additive models===
# TA2013 and REGC2013 are around 70 aggregate variables from the New Zealand
# census 2013, aggregated by territorial authority and regional council respectively.

head(TA2013)
names(TA2013)
Hmisc::describe(TA2013) # a lot of variables have one missing value

# turns out to be 'area outside territorial authority'
TA2013 %>%
  filter(is.na(PropPubAdmin2013)) %>%
  select(TA2013_NAM)

# create a copy without the TA number, and latitude and longitude (leaving in the NZTM coordinates) 
# and filtering out 
TA2013_sub <- TA2013 %>%
  select(-TA, -WGS84Longitude, -WGS84Latitude) %>%
  filter(TA2013_NAM != "Area Outside Territorial Authority")
# check we've knocked out exactly one row:
expect_equal(nrow(TA2013) - nrow(TA2013_sub), 1)

# make shorter names; remove the 2013:
names(TA2013_sub) <- gsub("2013", "", names(TA2013_sub))
# remove any trailing underscore
names(TA2013_sub) <- gsub("_$", "", names(TA2013_sub))

# let's get the idea of modelling with just a couple of variables
# Note this is not how we would do this as part of a modelling strategy - is just 
# for familiarising with the technique.  Let's say we want to investigate relationship
# of PropAreChildren to the amount people walk, jog and bike to work, controlling for
# other factors we can afford
mod1 <- gam(PropWalkJogBike ~ s(MedianIncome, k = 3) + s(PropSelfEmployed) + s(PropAgForFish) + PropAreChildren, 
            family = betar, data = TA2013_sub)

# your turn - as alternatives try with family = binomial (which is not appropriate) and 
# family = quasibinomial (which would be ok).  Have a read of ?family.mgcv

plot(mod1, pages = 1, all.terms = TRUE)

# your turn - look at the helpfile for plot.gam and try some different sorts of graphics
# or customisations

# your turn - look at the helpfile for s.  Refit the model above with k = 3 for
# MedianIncome, forcing a less squiggly fit.  How different does it look?


# one of the cool things about GAMs is they make it easy to model spatial effects.
# Just include the coordinates as explanatory variables:
mod2 <- gam(PropWalkJogBike ~ s(NZTM2000Easting) + s(NZTM2000Northing), 
            family = betar, data = TA2013_sub)
plot(mod2, pages = 1, shade = TRUE)

# in reality, we don't expect just north/south and east/west to somehow impact
# independently; they interact together
mod3 <- gam(PropWalkJogBike ~ s(NZTM2000Easting, NZTM2000Northing), 
            family = betar, data = TA2013_sub)
plot(mod3) # a map of NZ, of sorts...
# 3d perspective plot alternative:
plot(mod3, pers = TRUE)

# we're not usually interested in spatial effects in their own right, but
# more as a nuisance variable to include to deal with the spatial correlation
# in residuals.  So a model might be like
mod4 <- gam(PropWalkJogBike ~ s(MedianIncome) + s(PropSelfEmployed) + s(PropAgForFish) + PropAreChildren +
              s(NZTM2000Easting, NZTM2000Northing), 
            family = betar, data = TA2013_sub)
plot(mod4, pages = 1, all.terms = TRUE)
anova(mod4)
summary(mod4)
# However, notice that we're doing all this on only 67 data points.  4 or 5 degrees of freedom the most we can
# spend, and we're using up about 24 (how can we tell?)! so we need a rethink.  
# Of course, we should have done this before we started looking at the data.  
# We might decide we can afford only a very rough spatial smoothing which we control with
# the k parameter to the s() function,  and a single other control variable, which we choose as median income for
# theoretical / prior knowledge grounds that it encapsulates a lot of information

mod5 <- gam(PropWalkJogBike ~ MedianIncome + PropAreChildren +
              s(NZTM2000Easting, NZTM2000Northing, k = 4), 
            family = betar, data = TA2013_sub)
summary(mod5)
plot(mod5, all = TRUE, pages = 1)

# your turn - interpret the PropAreChildren coefficient and its statistical test

# bootstrapped confidence interval and validation
# first, some helper functions:
RMSE <- function(obs, pred){
  return(sqrt(mean(pred - obs) ^ 2))
}

R2 <- function(obs, pred){
  return(cor(obs, pred) ^ 2)
}
# discuss - what are these doing?

# then a function that fits the model to a bootstrap resample and returns
# 3 statistics of interest: root mean squae error (RMSE), r-squared (R2),
# and the coefficient of the impact of the proportion of children
my_function <- function(data, i){
  # Fit model on the bootstrap resample
  the_model <- gam(PropWalkJogBike ~ MedianIncome + PropAreChildren +
                     s(NZTM2000Easting, NZTM2000Northing, k = 4), 
                   family = betar, data = data[i, ])
  # use the bootstrap model to predict the results on the rest of the sample...
  
  predictions <- predict(the_model, newdata = data[-i, ], type = "response")
  # ... and calculate the root mean square error
  rmse <- RMSE(data[-i, "PropWalkJogBike"], predictions)
  r2 <- R2(data[-i, "PropWalkJogBike"], predictions)
  # estimate the slope we're interested in:
  PropAreChildren <- coef(the_model)["PropAreChildren"]
  return(c(rmse = rmse, r2 = r2, PropAreChildren = PropAreChildren))
}

# apply that function to 499 bootstrap resamples
booted <- boot(TA2013_sub, statistic = my_function, R = 499)
head(booted$t)

# confidence interval for the Proportion are children 
# (3rd element of statistic, so index=3):
boot.ci(booted, type = "perc", index = 3)

# Note that that the boot.ci method won't work for the "rmse" and "r2" parts of the
# bootstrap results.  Try it and discuss why... So instead:
mean(booted$t[ , 1]) # bootstrapped root mean square error
# Seems like a small number but remember must compare to:
mean(TA2013_sub$PropWalkJogBike)

# or
mean(booted$t[ , 2]) # bootstrapped R-squared.  Has the advantage of no scale
# compare to more optimistic result without validation:
summary(mod5)$r.sq
# but really R-squared in this case is just showing the correlation of predicted
# values with the actuals.  How might this go wrong?


# in fact if we want a good estimate of R2 (or other statistic) we can use the boot632 estimator
# see http://stats.stackexchange.com/questions/96739/what-is-the-632-rule-in-bootstrapping
summary(mod5)$r.sq * 0.368 + mean(booted$t[ , 2]) * 0.632

# YOUR TURN / homework
# adapt the above approach to the same data explaining one variable based on one or two others,
# none of which considered above.  Do still include the control for spatial correlation.

# If you still have time - go and finish the GLM work from week 1.

# If you *still* have time - experiment with some other data using some of the other
# families mgcv::gam accepts eg multinom, ocat, betar.  See ?family.mgcv

