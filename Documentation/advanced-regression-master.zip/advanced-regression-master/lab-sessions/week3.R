# MAKE A COPY OF THIS SCRIPT IN YOUR P:/r/%USERNAME% FOLDER 
# - DON'T WORK ON IT DIRECTLY BECAUSE IT IS SUBJECT TO
# BEING OVER-WRITTEN WITHOUT NOTICE!

# This session works with multiple implutation, primarily using the mice package

library(tidyverse)
library(mice)
library(testthat)
library(boot)
library(lattice) # for graphics used with mice
library(mgcv)    # for gam
library(Hmisc)   # for spearman2
library(Cairo)   # for printing to a PDF

user <- Sys.info()['login']
setwd(paste0("P:/R/", user, "/advanced-regression"))

load("AreaUnits2013.rda")   # copied from {nzcensus} package

summary(AreaUnits2013)
describe(AreaUnits2013)


# we are going to work with a deliberately cut down small set of variables
AreaData <- AreaUnits2013[ , c("PropUnemploymentBenefit2013", "PropInternetHH2013", "PropPrivateDwellings2013", 
                               "PropMaori2013", "Prop20to24_2013")]

# there are up to 149 missing values in some of the columns; 151 rows have at least one missing value:
summary(AreaData)
table(complete.cases(AreaData))

# model with dropping all non-complete rows (default)
mod1 <- glm(PropUnemploymentBenefit2013 ~ ., family = "quasibinomial", data = AreaData)
summary(mod1)


#============='basic' multiple imputation===============
# This illustrates the use of multiple imputation and pooling using the convenient mice package
AreaData_imp <- mice(AreaData)
AreaData_imp

densityplot(AreaData_imp)

mod_imp <- with(AreaData_imp, 
                glm(PropUnemploymentBenefit2013 ~ PropInternetHH2013 + PropPrivateDwellings2013 + PropMaori2013 + Prop20to24_2013, 
                    family = "quasibinomial"))

# summaries of all 5 models:
summary(mod_imp)

summary(pool(mod_imp))

# compare to coefficients from the "drop the variables" model
coef(mod1)
# generally, those from the version with imputation are a bit further away from zero than that which dropped variables

# YOUR TURN - do the above with a different set of variables
# Also, try one of the originals with gam instead of glm.  Try a different
# response family (apart from quasibinomial, what family/ies is appropriate
# for a proportion-like response?)


#======================multiple imputation for glm inside a bootstrap============

my_function <- function(x, i){
  # "multiple" imputation  with just one set of imputations.
  # using the version of x that has been resampled to include the rows
  # indicated by i:
  x_imp <- mice::complete(mice(x[i, ], m = 1, print = FALSE))  
  
  # fit model
  mod <- glm(PropUnemploymentBenefit2013 ~ ., data = x_imp, family = "quasibinomial")
  return(coef(mod))
}

# if doing for real, want perhaps 3000 resamples.  100 is just for practicing.
Area_booted <- boot(data = AreaData, statistic = my_function, R = 100)

plot(Area_booted)
Area_booted

# Confidence interval for the second parameter
boot.ci(Area_booted, type = "perc", index = 2)

# Compare the different confidence intervals

# All five bootstrapped - imputed confidence intervals (different imputation each bootstrap resample):
t(apply(Area_booted$t, 2, function(x){quantile(x, c(0.027, 0.975))})) # widest
# Model with no imputation:
confint(glm(PropUnemploymentBenefit2013 ~ ., family = "quasibinomial", data = AreaData))
# Multiple imputation, no bootstrap:
summary(pool(mod_imp))[ , 6:7]

# Discuss - you should if possible use the bootstrapped, imputed sample.  For a glm this is pretty straightforward
# as above, because it's simple to summarise effects.

# Your turn - make the minimal change to the above to skip the imputation stage
# and do the bootstrap on non-complete data.  How does it compare to the bootstrapped-imputed
# version?

#====================bigger example==============
# for illustration / do in your own time, rather than working through in lab


# using full dataset gam and estimating the values of k, and using bootstrap for validation
# this combination of gam, bootstrap and mice illustrates some real complexities.  When doing
# this for real you will need to make some pragmatic decisions about how far you go.  For example,
# bootstrap and multiple imputation greatly complicate the interpretation of individual relationships
# from explanatory variables to the response, but give you more confidence in the overall result.

AreaData <- AreaUnits2013 %>%
  # remove some redundant variables:
  select(-AU_NAM, -AU2014, -NZTM2000Easting, -NZTM2000Northing, 
           -PropFemale2013, -PropEuropean2013, -PropUnemployed2013) %>%
  # knock out missing ys (discuss - what step should be done here instead or at least as well?)
  filter(!is.na(PropUnemploymentBenefit2013))
  

# 1859 rows (if we don't restrict ourselves to complete cases), so 100 degrees of freedom to allocate
nrow(AreaData)
table(complete.cases(AreaData))

# How many degrees of freedom per variable?  We have 68 variables and about 100 degrees of freedom to allocate.
# Note - in an ideal world this process would automated and put inside the eventual bootstrap or validation.

area_sp <- spearman2(PropUnemploymentBenefit2013 ~ ., data = AreaData)
area_sp <- area_sp[order(-area_sp[ , "rho2"]), ]
area_sp[1:20, ]
# Decide to give k = 5 or 4 to the first 10, k = 4 or 3 to the next ten, all other variables linear

form <- formula(paste("PropUnemploymentBenefit2013 ~ 
             s(PropPartnered2013, k = 5) +
             s(PropNoMotorVehicle2013, k = 5) +
             s(PropSmoker2013, k = 5) +
             s(MedianIncome2013, k = 5) +
             s(PropSelfEmployed2013, k = 5) +
             s(PropManagers2013, k = 5) +
             s(PropEmployer2013, k = 5) +
             s(PropMaori2013, k = 4) +
             s(PropPacific2013, k = 4) +
             s(PropWorked50_59hours2013, k = 4) +
             s(PropInternetHH2013, k = 4) +
             s(PropOwnResidence2013, k = 4) +
             s(PropNotOwnedHH2013, k = 4) +
             s(PropFullTimeEmployed2013, k = 3) +
             s(PropSelfEmployedNoEmployees2013, k = 3) +
             s(PropPartTimeEmployed2013, k = 3) +
             s(PropWorkedHome2013, k = 3) +
             s(PropEmployee2013, k = 3) +
             s(MeanBedrooms2013, k = 3) +
             s(PropLandlordPublic2013) + ", 
             paste(rownames(area_sp)[-(1:20)], collapse = " + ") 
))

# what did we just create?
form

# try it out on an un-imputed dataset:
mod1 <- gam(form, data = AreaData, family ="quasibinomial")
anova(mod1)
summary(mod1)
plot(mod1, pages = 1)


# with imputation
AreaData_imp <- mice(AreaData)

# takes a couple of minutes on a 16GB i5:
mod2 <- with(AreaData_imp, gam(PropUnemploymentBenefit2013 ~ 
                                 s(PropPartnered2013, k = 5) +
                                 s(PropNoMotorVehicle2013, k = 5) +
                                 s(PropSmoker2013, k = 5) +
                                 s(MedianIncome2013, k = 5) +
                                 s(PropSelfEmployed2013, k = 5) +
                                 s(PropManagers2013, k = 5) +
                                 s(PropEmployer2013, k = 5) +
                                 s(PropMaori2013, k = 4) +
                                 s(PropPacific2013, k = 4) +
                                 s(PropWorked50_59hours2013, k = 4) +
                                 s(PropInternetHH2013, k = 4) +
                                 s(PropOwnResidence2013, k = 4) +
                                 s(PropNotOwnedHH2013, k = 4) +
                                 s(PropFullTimeEmployed2013, k = 3) +
                                 s(PropSelfEmployedNoEmployees2013, k = 3) +
                                 s(PropPartTimeEmployed2013, k = 3) +
                                 s(PropWorkedHome2013, k = 3) +
                                 s(PropEmployee2013, k = 3) +
                                 s(MeanBedrooms2013, k = 3) +
                                 s(PropLandlordPublic2013) +
                                 PropNoQualification2013 + Prop20to24_2013 + Prop45to49_2013 + PropMultiPersonHH2013 + 
                                 PropStudentAllowance2013 + Prop50to54_2013 + Prop25to29_2013 + PropSeparateHouse2013 + 
                                 PropWorkedOver60hours2013 + PropSeparated2013 + Prop60to64_2013 + PropBachelor2013 + 
                                 PropNoUnpaidActivities2013 + Prop55to59_2013 + Prop40to44_2013 + PropLabourers2013 + 
                                 PropSameResidence5YearsAgo2013 + PropWorked40_49hours2013 + PropProfServices2013 + 
                                 PropFTStudent2013 + Prop30to34_2013 + PropWorked20_29hours2013 + MedianRentHH2013 + 
                                 PropWalkJogBike2013 + PropDoctorate2013 + PropPTStudent2013 + PropNoReligion2013 + 
                                 PropAreChildren2013 + WGS84Longitude + PropProfessionals2013 + PropPublicTransport2013 + 
                                 PropMale2013 + PropAsian2013 + PropWorked10_19hours2013 + PropFinServices2013 + 
                                 WGS84Latitude + PropAgForFish2013 + Prop65AndOlder_2013 + PropPubAdmin2013 + 
                                 PropWorked30_39hours2013 + PropNoChildren2013 + PropTrades2013 + PropNZBorn2013 + 
                                 PropOverseas5YearsAgo2013 + Prop35to39_2013 + PropWorked1_9hours2013 + 
                                 PropWorked1_9hours2013 + NumberInHH2013 + PropPrivateDwellings2013
                                 , family = "quasibinomial"))

# Unfortunately, pooled results for s() in a gam are difficult to interpret
summary(pool(mod2))
# This is a non-trivial problem, see
# http://stats.stackexchange.com/questions/100245/how-to-summarize-gam-model-result-from-multiple-imputation-data-in-r
# See https://arxiv.org/pdf/1403.1124.pdf also for a more thorough look at causality with mgcv and mice, which is
# a bit beyond the scope of today's course

# You can get a qualitative sense of how vulnerable the modelling is to the
# random imputation by looking at the graphics
# show all the plots from the five models on a five page PDF
CairoPDF("imputed-gam-results.pdf", 16, 8)
par(bty = "l")
for(i in 1:5){
  plot(mod2$analyses[[i]], pages = 1)  
}
dev.off()

# In practice you will need a pragmatic decision about how to present results.  Graphically usually best.

# see https://people.maths.bris.ac.uk/~sw15190/mgcv/tampere/mgcv-advanced.pdf 
# for an argument for not bootstrapping.  But I think it's valuable particularly
# as a *validation* exercise.

my_function_full <- function(x, i){
  thedata <- mice::complete(mice(x[i, ], m = 1, print = FALSE))
  
  themodel <- gam(PropUnemploymentBenefit2013 ~ 
                      s(PropPartnered2013, k = 5) +
                      s(PropNoMotorVehicle2013, k = 5) +
                      s(PropSmoker2013, k = 5) +
                      s(MedianIncome2013, k = 5) +
                      s(PropSelfEmployed2013, k = 5) +
                      s(PropManagers2013, k = 5) +
                      s(PropEmployer2013, k = 5) +
                      s(PropMaori2013, k = 4) +
                      s(PropPacific2013, k = 4) +
                      s(PropWorked50_59hours2013, k = 4) +
                      s(PropInternetHH2013, k = 4) +
                      s(PropOwnResidence2013, k = 4) +
                      s(PropNotOwnedHH2013, k = 4) +
                      s(PropFullTimeEmployed2013, k = 3) +
                      s(PropSelfEmployedNoEmployees2013, k = 3) +
                      s(PropPartTimeEmployed2013, k = 3) +
                      s(PropWorkedHome2013, k = 3) +
                      s(PropEmployee2013, k = 3) +
                      s(MeanBedrooms2013, k = 3) +
                      s(PropLandlordPublic2013) +
                      PropNoQualification2013 + Prop20to24_2013 + Prop45to49_2013 + PropMultiPersonHH2013 + 
                      PropStudentAllowance2013 + Prop50to54_2013 + Prop25to29_2013 + PropSeparateHouse2013 + 
                      PropWorkedOver60hours2013 + PropSeparated2013 + Prop60to64_2013 + PropBachelor2013 + 
                      PropNoUnpaidActivities2013 + Prop55to59_2013 + Prop40to44_2013 + PropLabourers2013 + 
                      PropSameResidence5YearsAgo2013 + PropWorked40_49hours2013 + PropProfServices2013 + 
                      PropFTStudent2013 + Prop30to34_2013 + PropWorked20_29hours2013 + MedianRentHH2013 + 
                      PropWalkJogBike2013 + PropDoctorate2013 + PropPTStudent2013 + PropNoReligion2013 + 
                      PropAreChildren2013 + WGS84Longitude + PropProfessionals2013 + PropPublicTransport2013 + 
                      PropMale2013 + PropAsian2013 + PropWorked10_19hours2013 + PropFinServices2013 + 
                      WGS84Latitude + PropAgForFish2013 + Prop65AndOlder_2013 + PropPubAdmin2013 + 
                      PropWorked30_39hours2013 + PropNoChildren2013 + PropTrades2013 + PropNZBorn2013 + 
                      PropOverseas5YearsAgo2013 + Prop35to39_2013 + PropWorked1_9hours2013 + 
                      PropWorked1_9hours2013 + NumberInHH2013 + PropPrivateDwellings2013, 
                  family = "quasibinomial",
                  data = thedata
                  )
  # validate by using the model that was fit on the *resampled* data to predict the results on the *full* data:
  fulldata <- complete(mice(x, m = 1, print = FALSE))
  preds <- predict(themodel, newdata = fulldata)
  
  # root mean square error as a validation stat.  Not necessarily the best, could consider alternatives
  rmse <- sqrt(mean((preds - fulldata$PropUnemploymentBenefit2013) ^ 2))
  return(rmse)
}

# Set up parallel computing:
library(parallel)
library(doParallel)
cluster <- makeCluster(4) # for 4 processors 
registerDoParallel(cluster)

# Tell each CPU to load up the packages we need:
clusterEvalQ(cluster, {
  source("P:/r/common.Rprofile")
  library(mice)
  library(mgcv)
})

# Takes 22 minutes on my MBIE i5 (maxing out all 4 processors and using up to 6GB of RAM):
system.time({
  booted <- boot(AreaData, statistic = my_function_full, R = 100, cl = cluster, ncpus = 4, parallel = "snow")
})



booted # original wasn't too biased, a bit on the low side
plot(booted)

boot.ci(booted, type = "perc") # [3.807, 3.860]

stopCluster(cluster)

