# Keywords: glm, training, ships, housing satisfaction
# MAKE A COPY OF THIS SCRIPT IN YOUR P:/r/%USERNAME% FOLDER 
# - DON'T WORK ON IT DIRECTLY BECAUSE IT IS SUBJECT TO
# BEING OVER-WRITTEN WITHOUT NOTICE!
# Peter Ellis, November 2016

# This session covers generalized linear models

library(MASS)
library(ggplot2)
library(scales)
library(dplyr)
library(tidyr)
library(GGally) # for ggpairs
library(testthat)
library(boot)


user <- Sys.info()['login']
setwd(paste0("P:/R/", user, "/advanced-regression"))


# load up data (source noted in comment)
load("ships.rda")    # Stanford
load("copen.rda")    # Stanford
load("eg10.2.rda")   # Harrell
load("freak.rda")    # freakonemetrics



#============Poisson (count) response===============
#------------------- Example 1 - wave damge on cargo ships-----------------
# The "ships" and "copen" datasets were taken from
# http://data.princeton.edu/wws509/datasets/
#

# Ships is Lloyds Register fo Shipping data re wave damage
# to cargo ships.  The aim is to identify periods of poor
# consturction, problematic periods of operation, and ship type,
# while controlling for months at sea.  Here's the data:
ships


# quick look at the data - ok as all the variables are relevant:
ggpairs(ships, aes(colour = type))
Hmisc::describe(ships)

model_simple <- glm(damage ~ log(months) + type + construction + operation, 
             family = poisson, data = ships)
# discuss - why log months?  Has to do with link function for poisson family, 
# and marginal elasticity of damage, and how length at sea is thought to interact
# on damage

summary(model_simple)
# The prior assumed value of the coefficient for months was 1.0.  Why?  Is this close enough?
# note it is overdispersed

# fit a model without type - not as stepwise selection, but just so we can compare the two models
model_notype <-  glm(damage ~ log(months) + construction + operation, 
                     family = poisson, data = ships)

# compare the deviance of the two models.  Does it go down enough when type is included
anova(model_notype, model_simple, test = "Chisq")
# This suggests yes, there is evidence that ship type matters.

# BUT - note that the dispersion in the above is assumed to be 1.  
# Residual deviance is 37.8 on 24 degrees of freedom.
# so if we had to estimate dispersion we would be closer to 1.6.  This
# comes about because there is some inter-ship variability in accident proneness, so
# counts are not Poisson distributed after all.
# YOUR TURN: change the family from poisson to quasipoisson.  What difference does it make to the summary
# and to the analysis of deviance table?


# One question of particular interest is, does the type of ship interact with
# the period it was constructed:
model_simp_quasi <-  glm(damage ~ log(months) + construction + type + operation,
                         family = quasipoisson, data = ships)
model_interaction <- glm(damage ~ log(months) + construction * type + operation,
                         family = quasipoisson, data = ships)
anova(model_simp_quasi, model_interaction, test = "Chisq")
# same as:
anova(model_interaction, test = "Chisq")
# also equivalent to Likelihood Ratio Test:
anova(model_interaction, test = "LRT")
# So there is weak evidence of an interaction.  We also note that evidence of `type`
# is significant again... all up we probably cautiously conclude type might be a factor,

# examining diagnostic plots.  This is a bit different from for lm(), see the good answer by Scortchi at
# http://stats.stackexchange.com/questions/92394/checking-residuals-for-normality-in-generalised-linear-models
# eg the Normal QQ plot doesn't have anything useful to say.  But outlier and influence checks still good to do
par(mfrow = c(2, 2))
plot(model_interaction)

# YOUR TURN - look at the diagnostic plots of the no-interaction, quasi-poisson model.  Discuss.

# With a small dataset like this it can be useful to just have a visual look, compare the predictions
# of our two models with the actuals
round(data.frame(interaction_pred = predict(model_interaction, type = "response"),
           simple_pred            = predict(model_simp_quasi, type = "response"),
           actual                 = ships$damage))

# Overall conclusion.  I would drop the interaction model, but keep type in, and just warn
# that the evidence for type being important is doubtful, just enough to keep in the model
# (mostly because we nearly never exclude variables).  So this is my final model
summary(model_simp_quasi)
round(confint(model_simp_quasi), 2)
# if we were particularly concerned with these confidence intervals, what would we do to
# be sure we could make  them more robust?

#----------example 2 - housing conditions in Copenhagen-----------------
# 1681 residents of Copenhagen were classified in terms of housing type,
# their feeling of influence on apartment management, degree of contact with neighbours,
# satisfaction with housing conditions
# For today we are going to ignore the ordering in low-medium-high and treat as categorical
# variables.  Note that there are ways to deal with this
ggpairs(copen, aes (colour = satisfaction))
Hmisc::describe(copen)

# for more intuitive interpretation, will set the reference level for the factors
copen$satisfaction <- relevel(as.factor(copen$satisfaction), ref = "low")
copen$influence <- relevel(as.factor(copen$influence), ref = "low")
copen$contact <- relevel(as.factor(copen$contact), ref = "low")



# This modelling task, like most categorical crosstab-like analysis,
# is all about understanding and interpreting interactions

# YOUR TURN
# Fit a simple model with no interactions, explaining n based on all the other variables
# Fit a more complex model that lets the "satisfaction" variable interact with the other three
# Do a global test for those interactions.  Is there evidence that cell count in the 'satisfction'
# part of the cross tab is related to the other variables?  What would it mean if there wasn't 
# evidence ie if the p value was high?
# Use the confint() function (and its useful to wrap it inside round()) to get confidence intervals
# for the effect sizes of your final model.  How do we interpret the interaction effects? What stands out?

# having thought a bit about the modelling and the implicit null hypotheses of no interaction effect,
# this sort of chart starts to make more sense:
copen_array <- copen %>%
  mutate(contact = factor(paste("contact", contact), levels = c("contact low", "contact high"))) %>%
  mutate(satisfaction = factor(paste("sat", satisfaction), levels = c("sat low", "sat medium", "sat high"))) %>%
  mutate(influence = factor(paste("infl", influence), levels = c("infl low", "infl medium", "infl high"))) %>%
  reshape2::acast(satisfaction ~ influence ~ contact ~ housing, value.var = "n")
mosaicplot(copen_array, shade = TRUE)



#======================Binomial response======================
# Data from chapter 10 of Harrell, Regression Modeling Strategies
# we've already decided both variables will be in, so no variable selection needed
# and it's ok to look at the relationship of the variables to the response

# feel of data
ggpairs(eg10.2)
Hmisc::describe(eg10.2)

ggplot(eg10.2, aes(x = age, y = response, colour = sex, shape = sex)) +
  geom_point(position = position_jitter(width = 0.05, height = 0.05)) 
# discuss use of jitter
# discuss what would happen if we had a geom_smooth.  Good or bad idea?


# ignoring age, just the two dimensional cross tab:
with(eg10.2, table(sex, response))
chisq.test(with(eg10.2, table(sex, response)))

mod102_full <- glm(response ~ sex * age, data = eg10.2, family = binomial)
mod102_simple <- glm(response ~ sex + age, data = eg10.2, family = binomial)
summary(mod102_simple)
summary(mod102_full)

# likelihood ratio test, in this case the same as a Chi Square test
anova(mod102_full, test = "LRT")
anova(mod102_full, test = "Chisq")

# Discuss: disperson parameter, residual deviance, parameter estimates

# graphing results
# There are packages that look after this for you, but useful to know how to do it from scratch
X <- data.frame(
  age = seq(from = 30, to = 70, length.out = 41),
  sex = rep(c("female", "male"), each = 41))

X$response <- predict(mod102_simple, newdata = X, type = "response")
# discuss what other types of "response"

ggplot(eg10.2, aes(x = age, y = response, colour = sex, shape = sex)) +
  geom_point(position = position_jitter(width = 0.05, height = 0.05)) +
  geom_line(data = X)
# YOUR TURN - what if we used the full model (with interactions) to draw the lines instead?
#

# YOUR TURN
# The data frame "freak" comes from an example discussed at
# http://freakonometrics.hypotheses.org/8210
# which is an interesting read with some ideas about visualising residuals.
# Your task fit one or two glm models with Y1 being explained by X1 and X2
# Is there evidence of an interaction between X1 and X2?  If not, you can
# knock out the interaction.  Don't be tempted to remove a whole variable.
# Graph the relationship between Y and the strongest variable, with a line
# showing the fitted values

# to get you started:
ggpairs(freak)



