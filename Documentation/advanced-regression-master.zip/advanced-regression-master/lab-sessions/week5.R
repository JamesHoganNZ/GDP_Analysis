# MAKE A COPY OF THIS SCRIPT IN YOUR P:/r/%USERNAME% FOLDER 
# - DON'T WORK ON IT DIRECTLY BECAUSE IT IS SUBJECT TO
# BEING OVER-WRITTEN WITHOUT NOTICE!


# goal of script is to introduce random intercepts and slopes

library(lme4)
library(nlme)
library(ggplot2)
library(dplyr)
library(tidyr)
library(viridis)
library(gridExtra)

if(Sys.getenv("USERDNSDOMAIN") == "WD.GOVT.NZ") { ## if in MBIE environment
  user <- Sys.info()['login']
  setwd(paste0("P:/R/", user, "/advanced-regression"))
}  




#=============================================================================================
#============= Example 1: Impact of politeness on pitch of voice =============================

## data import; tidy up ======================================================================
# Example data from http://www.bodowinter.com/tutorial/bw_LME_tutorial.pdf
politeness <- read.csv("http://www.bodowinter.com/tutorial/politeness_data.csv")

## scan the data and meaning of variables
# frequency is pitch of voice
# attitude is an politeness - formally polite (pol) or informal (inf).  
# Subjects were asked to talk in different scenarios, once informal, once formal
head(politeness)
str(politeness)
# Each subject was given 7 scenarios, measured twice:
with(politeness, table(scenario, subject))


## remove NA before regressions
politeness <- politeness %>% filter(!is.na(frequency))




## SLR analysis ==============================================================================

# investigate the effect of attitude and gender on frequency
summary(m0 <- lm(frequency ~ attitude + gender, data = politeness))
ggplot(politeness, aes(y = frequency, x = gender, colour = attitude)) + geom_boxplot()

## Question 1: Is this model good? -- 
plot(density(resid(m0))) #A density plot
qqnorm(resid(m0)) # A quantile normal plot - good for checking normality
qqline(resid(m0))

AIC(m0);logLik(m0);anova(m0)

# why the residuals are not good? -- effects of subject and/or scenario haven't been taken into account 
ggplot(politeness %>% data.frame(residual = resid(m0)), 
       aes(y = residual, x = subject)) + geom_boxplot()

## your turn 1: check the effect of scenario to the frequency




## fixed effect model ========================================================================
summary(m1 <- lm(frequency ~ attitude + gender + subject + scenario, data = politeness))
AIC(m1);logLik(m1);anova(m1)
## Question 2: Is this model correct? and why? 

## Your turn 2: fix the code

# summary(m2 <- lm(frequency ~ attitude + gender + subject + factor(scenario), data = politeness))
summary(m2 <- lm(frequency ~ attitude + gender + subject + scenario, data = politeness))
AIC(m2);logLik(m2);anova(m2)

# Ohbs we got a NA coefficient, why? - http://stats.stackexchange.com/questions/25804/why-would-r-return-na-as-a-lm-coefficient

## could be colinearity.
## Question 3: How can we see this?

summary(m3 <- lm(frequency ~ attitude + subject + scenario, data = politeness))
AIC(m3);logLik(m3);anova(m3)
## Your turn 3: Explain why the m2/m3 are similar? and why they are better than m0?




## random/mixed effect model =================================================================
summary(m4 <- lme4::lmer(frequency ~ attitude + (1|subject) + (1|scenario), data = politeness))
coef(m4)
anova(m4, m3)
# Note:
#     1) anova gives analysis of deviance for lme/glm etc. -- why -- analysis of variance not applicable any more. 
#     2) compare to fixed effect model, the random/mixed effect model reduced the parameter number (model df) significantly. 

## Question 4: m4 worse than fixed effect model m3, why?

## exam the residual of m4
(p4 <- 
    ggplot(politeness %>% data.frame(residual = resid(m4)), 
           aes(y = residual, x = subject, colour = gender)) + geom_boxplot() + ggtitle("model 4")
)

## Your turn 4: exam the residual of m3 and m0 to see the difference. 




## random/mixed effect model - random slope ==================================================
summary(m5 <- lme4::lmer(frequency ~ attitude + (1 + gender|subject) + (1|scenario), data = politeness))
coef(m5)
anova(m5, m4)
(p5 <- 
    ggplot(politeness %>% data.frame(residual = resid(m5)), 
           aes(y = residual, x = subject, colour = gender)) + geom_boxplot() + ggtitle("model 5")
)

# Your turn - let attitude's slope vary by scenario; and let the gender slopes vary subject and/or scenario. - you may see some errors :).




## random/mixed effect model - Heteroscedasticity ============================================
# lme4::lmer() cannot cater for all mixed models, -- sometimes we need lme4::lmer

# Now we are trying to make distribution of subject condintioned on gender 
summary(m4 <- lme4::lmer(frequency ~ attitude + (1|subject) + (1|scenario), data = politeness))

# specify non-nested multiple random effect model could be difficult for nlme::lme, but the link https://biostatmatt.com/archives/2718 gives a tip
politeness2 <- politeness
politeness2$Dummy <- factor(1)
politeness2 <- groupedData(frequency ~ 1 | Dummy, politeness2)
summary(
  m6 <- nlme::lme(frequency ~ attitude, data=politeness2,
                    random=pdBlocked(list(pdIdent(~ 0 + subject),
                                          pdIdent(~ 0 + scenario)))))
# now we are able to replicate m4 by using nlme::lme 

# then we can specify the heteroscedasticity of subject, which is not provided by lme4:lmer
summary(m7 <- 
          nlme::lme(frequency ~ attitude, data=politeness2,
                    random=pdBlocked(list(pdIdent(~ 0 + subject),
                                          pdIdent(~ 0 + scenario))),
                    weights = varIdent(form= ~ subject | gender)
          ))

var(resid(m6)); var(resid(m7))
# Note the variance of residuals reduced. 

anova(m7, m6)
## Question 5: How to explain the comparison between m6 and m7? 

(p6 <- 
    ggplot(politeness %>% data.frame(residual = resid(m6)), 
       aes(y = residual, x = subject, colour = gender)) + geom_boxplot() + ggtitle("model 6")
)

(p7 <- 
    ggplot(politeness %>% data.frame(residual = resid(m7)), 
           aes(y = residual, x = subject, colour = gender)) + geom_boxplot() + ggtitle("model 7")
)
grid.arrange(p6, p7, ncol=2)

## Your turn 5: modify m7 to obtain the gender effect estimate.
summary(m8 <- 
          nlme::lme(frequency ~ attitude + gender, data=politeness2,
                    random=pdBlocked(list(pdIdent(~ 0 + subject),
                                          pdIdent(~ 0 + scenario))),
                    weights = varIdent(form= ~ subject | gender)
          ))




#=============================================================================================
#============= Example 2: MTAGDP =============================================================

## data import; tidy up ======================================================================
# 11MB so we only want to download once:
if(!file.exists("./tagdp_orig.rda")){
  tagdp_orig <- 
    read.csv("http://www.mbie.govt.nz/info-services/sectors-industries/regions-cities/research/modelled-territorial-authority-gross-domestic-product/document-and-image-library/MTAGDP_public.csv")
  save(tagdp_orig, file = "tagdp_orig.rda")
} else {
  load("tagdp_orig.rda")
}




## data import; tidy up ======================================================================
## data structure
head(tagdp_orig)
str(tagdp_orig)

(tagdp <- 
    tagdp_orig %>%
    group_by(Year, RGDP_industry, Region) %>%
    summarise(GDP_real = sum(GDP_real)) %>%
    ungroup() %>%
    group_by(RGDP_industry, Region) %>%
    mutate(GDP_change = c(NA, diff(GDP_real)) / GDP_real) %>%
    ungroup() %>%
    arrange(Region)
) %>% head

(tagdp_sel <- 
    tagdp %>%
    filter(RGDP_industry %in% c("Manufacturing", "Agriculture")) %>%
    select(-GDP_real) %>%
    filter(Year != min(Year)) %>%
    spread(RGDP_industry, GDP_change) 
) %>%
  ggplot(aes(x = Agriculture, y = Manufacturing, colour = Year)) +
  geom_smooth(method = "lm") +
  geom_line() +
  geom_point() +
  facet_wrap(~Region) +
  scale_color_viridis()

# may not be best to use LME, probably use a sVAR or something instead...
summary(m21 <- lm(Manufacturing ~ Agriculture + Year, data = tagdp_sel))
# week negative impact of Agriculture GDP change on Manufacturing GDP change
summary(m22 <- lmer(Manufacturing ~ Agriculture + Year + (1+Agriculture|Region), data = tagdp_sel))
coef(m22)
## Question 6: 0 variance by Region, why? no evidence of a Region effect?


# residuals over time
tagdp_sel %>%
  mutate(res = residuals(m22)) %>%
  ggplot(aes(x = Year, y = res)) +
  facet_wrap(~Region) +
  geom_line()

# look for autocorrelation
tagdp_sel %>%
  mutate(res0 = residuals(m22),
         res1 = c(NA, res0[-length(res0)])) %>%
  ggplot(aes(x = res0, y = res1)) +
  facet_wrap(~Region) +
  geom_point() +
  geom_smooth(method = "lm")

# if adjusting for autocorrelation, need to swap over to nlme:lme, rather than lme4:lmer
summary(m23 <- nlme::lme(Manufacturing ~ Agriculture + Year, random = ~(1+Agriculture)|Region, data = tagdp_sel))
coef(m23)
# compare to:
coef(m22)

library(nlme)
m24 <- lme(Manufacturing ~ Agriculture + Year, random = ~(1+Agriculture)|Region, data = tagdp_sel, correlation = corAR1())
summary(m24)
#=============================================================================================
