<style>
  .small-code pre code {
    font-size: 1em;
  }
</style>
  
  
  
Advanced Regression Week 3
========================================================
author: Peter Ellis
date: November 2016
width: 960
height: 700
font-family: 'Calibri'





Course overview
========================================================
  
  Exposure to methods beyond linear regression and ordinary least squares; and able to apply them to work situations.

1. *Generalized linear model* - dealing with response variables that are counts, proportions and more 
2. *Generalized additive model* - dealing with curvature 
3. *Multiple imputation* - dealing with missing data
4. *Elastic net regularization* - dealing with too many variables and variable collinearity
5. *Mixed effects models* - randomness at group level as well as for individuals


3. Multiple imputation
==================================


Different types of missing:

1. MCAR - missing completely at random
2. MAR - missing at random ie with some relationship to observed data
3. IM - Informative missing, not at random, in some meaningful way relating to a non-observed factor.

Today is all about handling situation #2 better.  We treat #1 as a special case of #2.

> "In many cases, there is no fix for IM nor is there a way to use the data to test for the existence of IM."

Pitfalls of only using complete data
=================

- Inefficient
- Adding more variables reduces the number of cases (which is inefficient again, and also makes it harder to compare models)
- Structure in the reason for being missing will always lead to biased analysis, which might have been correctable.

> "In general, observations  should only be discarded if there is a rarely missing predictor of overriding importance that cannot be reliably imputed from other information, or if the fraction of observations excluded is very small and the original sample size is large.  Even then, there is no advantage of such deletion other than saving analyst time"


Imputation
=====================
- We replace the missing data with new, derived values.
    - this always requires an implicit predictive statistical model for the variables missing values, even if it is as simple as "replace with the mode value".
- Those values are based on what is happening elsewhere in the dataset.
- Then we analyse the full dataset as though we had it all along.

Clearly, the choice of which values to insert is important!  And the values will certainly be wrong.  Analysis will certainly look more confident than it should, and might also be biased.  Simple methods (like mode substitution) are known to be **highly** likely to introduce bias to results.

Pitfalls of simple imputation
=====================

When $x_j$ is a predictor of $y$ and $x_j$ is sometimes missing, ignoring the relationship between them while imputing biases regression coefficients for $x_j$ towards zero.

Using $y$ to impute one or more of the $x$ feels like cheating, but the relationship between them in the imputed subset will only be as strong as that evidenced by the non-missing data.

When y is missing?
========================

Common (and usually ok) practice to discard observations with missing $y$.

But before doing so, at a minimum should characterise the tendency for $y$ to be missing - usually by logistic regression with missingness as the response variable and everything else as explanatory variables.

Better imputation
=================
- Use as good a model as possible, 
  - incorporating all the information available that is suspected to be relevant to the data going missing and what its value would be if we had it
  - using the best predictive analytics methods available
- Acknowledge the randomness in the imputation process and take it into account in analysis:
  - Cross-validation and bootstrap should envelop the imputation
  - Should do the imputation multiple times, giving differing values in accordance with the distribution predicted by our model, and incorporate the uncertainty of this into the overall conclusions.
  
  
Multivariate imputation by chained equations (MICE)  
====================

- in sequence, each incomplete column in the data gets imputed values from a predictive model based on other columns
- imputed values should be generated at random ie incorporate individual uncertainty, not just model uncertainty
- when predictive columns are missing data, their latest imputed values are used (so need to start somewhere simple for the first iteration)
- rinse and repeat
- store the results as multiple sets of data
- perform your analysis on all those multiple sets 
- pool the results and use pooled variance estimates for inference

Simple example
===========
class: small-code


```r
summary(nhanes)
```

```
      age            bmi             hyp             chl       
 Min.   :1.00   Min.   :20.40   Min.   :1.000   Min.   :113.0  
 1st Qu.:1.00   1st Qu.:22.65   1st Qu.:1.000   1st Qu.:185.0  
 Median :2.00   Median :26.75   Median :1.000   Median :187.0  
 Mean   :1.76   Mean   :26.56   Mean   :1.235   Mean   :191.4  
 3rd Qu.:2.00   3rd Qu.:28.93   3rd Qu.:1.000   3rd Qu.:212.0  
 Max.   :3.00   Max.   :35.30   Max.   :2.000   Max.   :284.0  
                NA's   :9       NA's   :8       NA's   :10     
```


```r
imp <- mice(nhanes)
```


```r
names(imp)
```

```
 [1] "call"            "data"            "m"              
 [4] "nmis"            "imp"             "method"         
 [7] "predictorMatrix" "visitSequence"   "form"           
[10] "post"            "seed"            "iteration"      
[13] "lastSeedValue"   "chainMean"       "chainVar"       
[16] "loggedEvents"    "pad"            
```

==================
class: small-code

```r
imp
```

```
Multiply imputed data set
Call:
mice(data = nhanes)
Number of multiple imputations:  5
Missing cells per column:
age bmi hyp chl 
  0   9   8  10 
Imputation methods:
  age   bmi   hyp   chl 
   "" "pmm" "pmm" "pmm" 
VisitSequence:
bmi hyp chl 
  2   3   4 
PredictorMatrix:
    age bmi hyp chl
age   0   0   0   0
bmi   1   0   1   1
hyp   1   1   0   1
chl   1   1   1   0
Random generator seed value:  NA 
```

===================
class: small-code

```r
cbind(nhanes, mice::complete(imp, 1), mice::complete(imp, 2))
```

```
   age  bmi hyp chl age  bmi hyp chl age  bmi hyp chl
1    1   NA  NA  NA   1 35.3   2 238   1 35.3   1 199
2    2 22.7   1 187   2 22.7   1 187   2 22.7   1 187
3    1   NA   1 187   1 30.1   1 187   1 26.3   1 187
4    3   NA  NA  NA   3 21.7   1 206   3 20.4   2 206
5    1 20.4   1 113   1 20.4   1 113   1 20.4   1 113
6    3   NA  NA 184   3 21.7   2 184   3 24.9   1 184
7    1 22.5   1 118   1 22.5   1 118   1 22.5   1 118
8    1 30.1   1 187   1 30.1   1 187   1 30.1   1 187
9    2 22.0   1 238   2 22.0   1 238   2 22.0   1 238
10   2   NA  NA  NA   2 30.1   1 206   2 20.4   1 118
11   1   NA  NA  NA   1 33.2   1 199   1 27.2   1 187
12   2   NA  NA  NA   2 20.4   1 238   2 27.4   1 229
13   3 21.7   1 206   3 21.7   1 206   3 21.7   1 206
14   2 28.7   2 204   2 28.7   2 204   2 28.7   2 204
15   1 29.6   1  NA   1 29.6   1 187   1 29.6   1 187
16   1   NA  NA  NA   1 33.2   1 204   1 26.3   1 187
17   3 27.2   2 284   3 27.2   2 284   3 27.2   2 284
18   2 26.3   2 199   2 26.3   2 199   2 26.3   2 199
19   1 35.3   1 218   1 35.3   1 218   1 35.3   1 218
20   3 25.5   2  NA   3 25.5   2 184   3 25.5   2 284
21   1   NA  NA  NA   1 30.1   1 131   1 22.5   1 238
22   1 33.2   1 229   1 33.2   1 229   1 33.2   1 229
23   1 27.5   1 131   1 27.5   1 131   1 27.5   1 131
24   3 24.9   1  NA   3 24.9   1 204   3 24.9   1 218
25   2 27.4   1 186   2 27.4   1 186   2 27.4   1 186
```

Graphic comparisons
=====================
class: small-code


```r
densityplot(imp)
```

![plot of chunk unnamed-chunk-7](week3-figure/unnamed-chunk-7-1.png)

More graphic comparisons
=====================
class: small-code


```r
xyplot(imp, bmi ~ age | .imp, pch=c(1, 20), cex=c(1, 1.5))
```

![plot of chunk unnamed-chunk-8](week3-figure/unnamed-chunk-8-1.png)


More graphic comparisons
=====================
class: small-code


```r
stripplot(imp, pch = c(1, 20), cex = c(1, 1.5))
```

![plot of chunk unnamed-chunk-9](week3-figure/unnamed-chunk-9-1.png)

Analysis
======================
class: small-code


```r
micemodel <- with(imp, lm(age ~ bmi + hyp + chl))
micemodel
```

```
call :
with.mids(data = imp, expr = lm(age ~ bmi + hyp + chl))

call1 :
mice(data = nhanes)

nmis :
age bmi hyp chl 
  0   9   8  10 

analyses :
[[1]]

Call:
lm(formula = age ~ bmi + hyp + chl)

Coefficients:
(Intercept)          bmi          hyp          chl  
   2.518802    -0.117835     0.537790     0.009158  


[[2]]

Call:
lm(formula = age ~ bmi + hyp + chl)

Coefficients:
(Intercept)          bmi          hyp          chl  
   1.969921    -0.096804     0.577213     0.008308  


[[3]]

Call:
lm(formula = age ~ bmi + hyp + chl)

Coefficients:
(Intercept)          bmi          hyp          chl  
     1.5472      -0.1027       0.7427       0.0103  


[[4]]

Call:
lm(formula = age ~ bmi + hyp + chl)

Coefficients:
(Intercept)          bmi          hyp          chl  
   1.680115    -0.098468     0.708376     0.009243  


[[5]]

Call:
lm(formula = age ~ bmi + hyp + chl)

Coefficients:
(Intercept)          bmi          hyp          chl  
   1.699954    -0.087154     0.412015     0.009568  
```


============
class: small-code


```r
summary(micemodel)
```

```

 ## summary of imputation 1 :

Call:
lm(formula = age ~ bmi + hyp + chl)

Residuals:
     Min       1Q   Median       3Q      Max 
-0.83234 -0.28120 -0.01581  0.29056  1.00929 

Coefficients:
             Estimate Std. Error t value Pr(>|t|)
(Intercept)  2.518802   0.751894   3.350  0.00303
bmi         -0.117835   0.022724  -5.186 3.87e-05
hyp          0.537790   0.254023   2.117  0.04636
chl          0.009158   0.002878   3.182  0.00449

Residual standard error: 0.5166 on 21 degrees of freedom
Multiple R-squared:  0.6616,	Adjusted R-squared:  0.6133 
F-statistic: 13.69 on 3 and 21 DF,  p-value: 3.601e-05


 ## summary of imputation 2 :

Call:
lm(formula = age ~ bmi + hyp + chl)

Residuals:
    Min      1Q  Median      3Q     Max 
-1.3464 -0.3494 -0.0154  0.2027  1.3346 

Coefficients:
             Estimate Std. Error t value Pr(>|t|)
(Intercept)  1.969921   0.893298   2.205  0.03872
bmi         -0.096804   0.030659  -3.157  0.00475
hyp          0.577213   0.345386   1.671  0.10952
chl          0.008308   0.003312   2.508  0.02041

Residual standard error: 0.6032 on 21 degrees of freedom
Multiple R-squared:  0.5385,	Adjusted R-squared:  0.4726 
F-statistic: 8.169 on 3 and 21 DF,  p-value: 0.0008561


 ## summary of imputation 3 :

Call:
lm(formula = age ~ bmi + hyp + chl)

Residuals:
    Min      1Q  Median      3Q     Max 
-0.9466 -0.3817 -0.1263  0.1845  1.6284 

Coefficients:
             Estimate Std. Error t value Pr(>|t|)
(Intercept)  1.547160   0.990795   1.562  0.13334
bmi         -0.102672   0.034557  -2.971  0.00729
hyp          0.742731   0.322203   2.305  0.03146
chl          0.010298   0.003842   2.680  0.01401

Residual standard error: 0.6097 on 21 degrees of freedom
Multiple R-squared:  0.5286,	Adjusted R-squared:  0.4613 
F-statistic:  7.85 on 3 and 21 DF,  p-value: 0.001062


 ## summary of imputation 4 :

Call:
lm(formula = age ~ bmi + hyp + chl)

Residuals:
     Min       1Q   Median       3Q      Max 
-0.95060 -0.23595 -0.04349  0.16149  1.15935 

Coefficients:
             Estimate Std. Error t value Pr(>|t|)
(Intercept)  1.680115   0.705841   2.380 0.026849
bmi         -0.098468   0.022316  -4.412 0.000242
hyp          0.708376   0.250190   2.831 0.010000
chl          0.009243   0.002771   3.336 0.003135

Residual standard error: 0.4779 on 21 degrees of freedom
Multiple R-squared:  0.7104,	Adjusted R-squared:  0.669 
F-statistic: 17.17 on 3 and 21 DF,  p-value: 7.254e-06


 ## summary of imputation 5 :

Call:
lm(formula = age ~ bmi + hyp + chl)

Residuals:
    Min      1Q  Median      3Q     Max 
-1.4282 -0.2800 -0.1213  0.1728  1.5155 

Coefficients:
             Estimate Std. Error t value Pr(>|t|)
(Intercept)  1.699954   0.920613   1.847  0.07896
bmi         -0.087154   0.030145  -2.891  0.00874
hyp          0.412015   0.363931   1.132  0.27034
chl          0.009568   0.002888   3.313  0.00331

Residual standard error: 0.6092 on 21 degrees of freedom
Multiple R-squared:  0.5294,	Adjusted R-squared:  0.4622 
F-statistic: 7.874 on 3 and 21 DF,  p-value: 0.001044
```

You can look at individual models
=================
class: small-code


```r
par(mfrow = c(2, 2))
plot(micemodel$analyses[[5]])
```

![plot of chunk unnamed-chunk-12](week3-figure/unnamed-chunk-12-1.png)


And pool the results
================
class: small-code

```r
summary(pool(micemodel))
```

```
                     est          se         t       df    Pr(>|t|)
(Intercept)  1.883190482 0.958083936  1.965580 13.47901 0.070294961
bmi         -0.100586709 0.031012544 -3.243420 14.77562 0.005547052
hyp          0.595624815 0.343598428  1.733491 13.91956 0.105091397
chl          0.009315099 0.003260239  2.857183 17.84572 0.010532667
                   lo 95       hi 95 nmis       fmi     lambda
(Intercept) -0.179171708  3.94555267   NA 0.2934479 0.19585109
bmi         -0.166775920 -0.03439750    9 0.2512274 0.15629955
hyp         -0.141720270  1.33296990    8 0.2789760 0.18232111
chl          0.002461345  0.01616885   10 0.1488759 0.05855045
```


Rules of thumb
======================

- **Proportion of missings <0.05**.  Doesn't matter much what you do. Complete case analysis an option.
- **Proportion of missings 0.05 to 0.15**.  Single imputation probably ok but multiple imputation doesn't hurt.
- **Proportion of missings > 0.15**. Same considerations as previous case, and adjusting variances for imputation even more important.  Refit the model on the subset of observations for which a predictor is not missing as a check.  Multiple imputation a must.

Remember that the imputation process needs to be built into the validation (bootstrap or cross-validation).  But when you get to that stage, you might simplify by doing a single (still chained equation) imputation for each resample.


