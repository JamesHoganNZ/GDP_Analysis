source("p:/r/common.Rprofile")
projdir <- getwd()