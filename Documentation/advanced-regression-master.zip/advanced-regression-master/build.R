library(knitr)
library(rmarkdown)
library(shinyapps)

# Note.  The data in /data/ is all created in the separate Graphics Fundamentals
# repository and has just been copied in.


# git moves over the source for session1 and session3 but need to save the html versions by hand


source("data-prep.R")


setwd(paste0(projdir, "/Session5"))
render("session5.Rmd")

