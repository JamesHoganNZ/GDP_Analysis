setwd(projdir)
trainees <- c("ellisp", "zhangw2", "youngn", "saglams", "talosat",
              "greenr", "renv", "vennels", "havukki", "sadetsk",
              "pledgel","wuh", "aggior", "allanc2", "warrinj2")
for(i in 1:length(trainees)){
    try(dir.create(paste0("P:/R/", trainees[i], "/advanced-regression")))    
}


datasets <- list.files("./data") 
labsessions <- list.files("./Lab-Sessions")[5]
for(i in 1:length(trainees)){
      # file.copy(from = paste0("data/", datasets), 
      #           to = paste0("P:/R/", trainees[i], "/advanced-regression/", datasets),
      #           overwrite = TRUE)    
    file.copy(from = paste0("Lab-Sessions/", labsessions),
              to = paste0("P:/R/", trainees[i], 
                          "/advanced-regression/", labsessions),
              overwrite = TRUE)    
    
}


