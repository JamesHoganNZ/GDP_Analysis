<style>
.small-code pre code {
  font-size: 1em;
}
</style>



Advanced Regression
========================================================
author: Peter Ellis
date: November 2016
width: 960
height: 700
font-family: 'Calibri'





Course overview
========================================================

Exposure to methods beyond linear regression and ordinary least squares; and able to apply them to work situations.

1. *Generalized linear model* - dealing with response variables that are counts, proportions and more 
2. *Generalized additive model* - dealing with curvature 
3. *Multiple imputation* - dealing with missing data
4. *Elastic net regularization* - dealing with too many variables and variable collinearity
5. *Mixed effects models* - randomness at group level as well as for individuals

Assumed knowledge
==========================

 - linear regression
 - estimation methods - ordinary least squares and robust measures like least trimmed squares
 - bootstrap
 - cross-validation

It helps if you know a bit about maximum likelihood, linear algebra and calculus, but isn't essential.

1. Generalized Linear Model
====================================

Definitively introduced in McCullagh and Nelder (1989), *Generalized Linear Models*.

We're used to the classical linear regression model...

The components of $\mathbf{y}$ are independent Normal variables with constant variance $\sigma^2$ and:

$$E(\mathbf{y}) = \mathbf{X\beta}$$

The generalization
====================
A three-part specification:

1. The *random component:* the components of $\mathbf{y}$ are independent with a distribution from any of the exponential family of distributions, with $E(\mathbf{y}) = \mu$ and ${\sigma_y}^2$ some function of $\mu$ determined by the particular distribution.
2. The *systematic component*: covariates $\mathbf{x_1,x_2,...,x_p}$ produce a *linear predictor $\eta$* given by $$\mathbf{\eta}=\sum_{j=1}^p{x_j\beta_j}$$
3. The *link* between the random and systematic components:
$$\mathbf{\eta}=g(\mathbf{\mu})$$

Which gives us the GLM:
=======================
The components of $\mathbf{y}$ are independent variables from a distribution in the linear exponential family with:

$$g(E(\mathbf{y}))= \mathbf{X\beta}$$

and

$${\sigma_y}^2=\phi V(\mathbf{\mu})$$

where $\phi$ is a scaling parameter and $V(.)$ is a matrix of functions that define the variances and covariances of the responses (all non-diagonal elements being zero because of the independence assumption).

All we minimally need to specify is the *link function* and *variance as a function of the mean*.


Example applications
=========================

|Family          | Canonical link |Link formula, $X\beta=?$      | Variance proportionate to    |Application|
|-----------------|----------|:----------:|:---------------------:|--------------|
|Normal        |identity| $\mu$               |constant             |Linear response, constant variance|
|Binomial      |logit| $ln(\frac{\mu}{1-\mu})$   |$\mu(1-\mu)$         |Proportions, success-failure, etc|
|Poisson       |logarithm|$ln(\mu)$    |$\mu$                |Counts|
|Gamma          |inverse  |$\frac{1}{\mu}$             |$\mu^2$       |Continuous, right skewed, positive|
|Quasi         |you choose| |you choose|Wide variety, minimal assumptions                |

See `?family`.

Estimation uses iterative re-weighted least squares and relies heavily on the variance estimates.

RCT counts example (from ?glm)
================



Tidy:

```r
xtable(rct, dig = 0) 
```

<!-- html table generated in R 3.3.2 by xtable 1.8-2 package -->
<!-- Sun Nov 13 11:51:55 2016 -->
<table border=1>
<tr> <th> treat </th> <th> outcome </th> <th> counts </th>  </tr>
  <tr> <td> A </td> <td> 1 </td> <td align="right"> 18 </td> </tr>
  <tr> <td> A </td> <td> 2 </td> <td align="right"> 17 </td> </tr>
  <tr> <td> A </td> <td> 3 </td> <td align="right"> 15 </td> </tr>
  <tr> <td> B </td> <td> 1 </td> <td align="right"> 20 </td> </tr>
  <tr> <td> B </td> <td> 2 </td> <td align="right"> 10 </td> </tr>
  <tr> <td> B </td> <td> 3 </td> <td align="right"> 20 </td> </tr>
  <tr> <td> C </td> <td> 1 </td> <td align="right"> 25 </td> </tr>
  <tr> <td> C </td> <td> 2 </td> <td align="right"> 13 </td> </tr>
  <tr> <td> C </td> <td> 3 </td> <td align="right"> 12 </td> </tr>
   </table>

***

Matrix:

```r
rct_mat
```

```
   1  2  3
A 18 17 15
B 20 10 20
C 25 13 12
```

Poisson model:
<small>

```r
glm_D93 <- glm(counts ~ outcome + treat, family = poisson)
```
</small>

=============


<table style="text-align:center"><tr><td colspan="2" style="border-bottom: 1px solid black"></td></tr><tr><td style="text-align:left"></td><td><em>Dependent variable:</em></td></tr>
<tr><td></td><td colspan="1" style="border-bottom: 1px solid black"></td></tr>
<tr><td style="text-align:left"></td><td>counts</td></tr>
<tr><td colspan="2" style="border-bottom: 1px solid black"></td></tr><tr><td style="text-align:left">outcome2</td><td>-0.454<sup>**</sup></td></tr>
<tr><td style="text-align:left"></td><td>(0.202)</td></tr>
<tr><td style="text-align:left"></td><td></td></tr>
<tr><td style="text-align:left">outcome3</td><td>-0.293</td></tr>
<tr><td style="text-align:left"></td><td>(0.193)</td></tr>
<tr><td style="text-align:left"></td><td></td></tr>
<tr><td style="text-align:left">treatB</td><td>0.000</td></tr>
<tr><td style="text-align:left"></td><td>(0.200)</td></tr>
<tr><td style="text-align:left"></td><td></td></tr>
<tr><td style="text-align:left">treatC</td><td>0.000</td></tr>
<tr><td style="text-align:left"></td><td>(0.200)</td></tr>
<tr><td style="text-align:left"></td><td></td></tr>
<tr><td style="text-align:left">Constant</td><td>3.045<sup>***</sup></td></tr>
<tr><td style="text-align:left"></td><td>(0.171)</td></tr>
<tr><td style="text-align:left"></td><td></td></tr>
<tr><td colspan="2" style="border-bottom: 1px solid black"></td></tr><tr><td style="text-align:left">Observations</td><td>9</td></tr>
<tr><td style="text-align:left">Log Likelihood</td><td>-23.381</td></tr>
<tr><td style="text-align:left">Akaike Inf. Crit.</td><td>56.761</td></tr>
<tr><td colspan="2" style="border-bottom: 1px solid black"></td></tr><tr><td style="text-align:left"><em>Note:</em></td><td style="text-align:right"><sup>*</sup>p<0.1; <sup>**</sup>p<0.05; <sup>***</sup>p<0.01</td></tr>
</table>

Interested in the *interaction*
==============

<small>

```r
glm_D93_full <- glm(counts ~ outcome * treat, family = poisson, data = rct) 
anova(glm_D93_full, test = "Chi")
```

```
Analysis of Deviance Table

Model: poisson, link: log

Response: counts

Terms added sequentially (first to last)

              Df Deviance Resid. Df Resid. Dev Pr(>Chi)
NULL                              8    10.5814         
outcome        2   5.4523         6     5.1291  0.06547
treat          2   0.0000         4     5.1291  1.00000
outcome:treat  4   5.1291         0     0.0000  0.27430
```
</small>

Equivalent to Chi-square test
===============
Testing for the interaction between two factor variables in a Poisson GLM is actually equivalent to the traditional basic Chi Square test for independence in a contingency table:

```r
chisq.test(rct_mat)
```

```

	Pearson's Chi-squared test

data:  rct_mat
X-squared = 5.1732, df = 4, p-value = 0.27
```

But doing this within the GLM framework is much more flexible (eg can also control for continuous explanatory variables in the same model).


The familiar generic functions all work:
=============


```r
round(confint(glm_D93_full) , 1)
```

```
                2.5 % 97.5 %
(Intercept)       2.4    3.3
outcome2         -0.7    0.6
outcome3         -0.9    0.5
treatB           -0.5    0.8
treatC           -0.3    0.9
outcome2:treatB  -1.7    0.4
outcome3:treatB  -0.7    1.1
outcome2:treatC  -1.6    0.3
outcome3:treatC  -1.5    0.4
```

Note that validation is an awkward concept here - neither the bootstrap nor cross-validation work well with this data structure so would need to do some reshaping and clear thinking.


===========
class: small-code

```r
plot(fitted(glm_D93_full), rct$counts)
```

![plot of chunk unnamed-chunk-10](session1-figure/unnamed-chunk-10-1.png)

===========
class: small-code

```r
ggplot(rct, aes(y = counts, x = fitted(glm_D93), 
                colour = outcome, label = treat))  +
  geom_text(size = 9) +
  labs(x = "Predicted counts with no effect", y = "Actual counts") +
  ggtitle("Counts of outcome for treatments A, B and C")
```

![plot of chunk unnamed-chunk-11](session1-figure/unnamed-chunk-11-1.png)

The link function in action
===============
class: small-code


```r
plot(predict(glm_D93_full, type = "response"), predict(glm_D93_full, type = "link"))
```

![plot of chunk unnamed-chunk-12](session1-figure/unnamed-chunk-12-1.png)


Binary (0/1) example - low birth weight
================
class: small-code

```r
head(lowweights, 10) # adapted from library(MASS)
```


<!-- html table generated in R 3.3.2 by xtable 1.8-2 package -->
<!-- Sun Nov 13 11:51:56 2016 -->
<table border=1>
<tr> <th> low </th> <th> age </th> <th> lwt </th> <th> race </th> <th> smoke </th> <th> ptl </th> <th> ht </th> <th> ui </th> <th> ftv </th>  </tr>
  <tr> <td> 0 </td> <td align="right"> -0.80 </td> <td align="right"> 1.71 </td> <td> black </td> <td align="right">   0 </td> <td> FALSE </td> <td align="right">   0 </td> <td align="right">   1 </td> <td> 0 </td> </tr>
  <tr> <td> 0 </td> <td align="right"> 1.84 </td> <td align="right"> 0.82 </td> <td> other </td> <td align="right">   0 </td> <td> FALSE </td> <td align="right">   0 </td> <td align="right">   0 </td> <td> 2+ </td> </tr>
  <tr> <td> 0 </td> <td align="right"> -0.61 </td> <td align="right"> -0.81 </td> <td> white </td> <td align="right">   1 </td> <td> FALSE </td> <td align="right">   0 </td> <td align="right">   0 </td> <td> 1 </td> </tr>
  <tr> <td> 0 </td> <td align="right"> -0.42 </td> <td align="right"> -0.71 </td> <td> white </td> <td align="right">   1 </td> <td> FALSE </td> <td align="right">   0 </td> <td align="right">   1 </td> <td> 2+ </td> </tr>
  <tr> <td> 0 </td> <td align="right"> -0.99 </td> <td align="right"> -0.75 </td> <td> white </td> <td align="right">   1 </td> <td> FALSE </td> <td align="right">   0 </td> <td align="right">   1 </td> <td> 0 </td> </tr>
  <tr> <td> 0 </td> <td align="right"> -0.42 </td> <td align="right"> -0.19 </td> <td> other </td> <td align="right">   0 </td> <td> FALSE </td> <td align="right">   0 </td> <td align="right">   0 </td> <td> 0 </td> </tr>
  <tr> <td> 0 </td> <td align="right"> -0.23 </td> <td align="right"> -0.39 </td> <td> white </td> <td align="right">   0 </td> <td> FALSE </td> <td align="right">   0 </td> <td align="right">   0 </td> <td> 1 </td> </tr>
  <tr> <td> 0 </td> <td align="right"> -1.18 </td> <td align="right"> -0.88 </td> <td> other </td> <td align="right">   0 </td> <td> FALSE </td> <td align="right">   0 </td> <td align="right">   0 </td> <td> 1 </td> </tr>
  <tr> <td> 0 </td> <td align="right"> 1.09 </td> <td align="right"> -0.22 </td> <td> white </td> <td align="right">   1 </td> <td> FALSE </td> <td align="right">   0 </td> <td align="right">   0 </td> <td> 1 </td> </tr>
  <tr> <td> 0 </td> <td align="right"> 0.52 </td> <td align="right"> -0.55 </td> <td> white </td> <td align="right">   1 </td> <td> FALSE </td> <td align="right">   0 </td> <td align="right">   0 </td> <td> 0 </td> </tr>
   </table>

Example modelling strategy
====================
class: small-code
Looking for race interaction impacts


```r
mod_full <- glm(low ~ race * (.), family = binomial, data = lowweights)

mod_smaller <- glm(low ~ ., family = binomial, data = lowweights)
```

Note that

- `lwt` is (scaled) weight of mother
- `ptl` is an indicator of previous premature labours
- `ht` is a history of hypertension
- `ui` is uterine irritability
- `ftv` is number of physician visits in first trimester
- `age`, `smoke` and `race` are self-explanatory (but `age` is scaled)

==============
class: small-code


```r
mod_full
```

```

Call:  glm(formula = low ~ race * (.), family = binomial, data = lowweights)

Coefficients:
      (Intercept)          raceblack          raceother  
         -2.10314           -3.07915            0.67890  
              age                lwt              smoke  
         -0.15955           -0.38732            0.95745  
          ptlTRUE                 ht                 ui  
          1.77859            1.53736           -0.01435  
             ftv1              ftv2+      raceblack:age  
         -0.76454            0.28217           -0.93202  
    raceother:age      raceblack:lwt      raceother:lwt  
         -0.21010           -1.22224           -0.50915  
  raceblack:smoke    raceother:smoke  raceblack:ptlTRUE  
          3.35133           -1.28164           -0.48283  
raceother:ptlTRUE       raceblack:ht       raceother:ht  
         -0.28659            7.31820            0.27208  
     raceblack:ui       raceother:ui     raceblack:ftv1  
          6.85748            0.98083            3.32288  
   raceother:ftv1    raceblack:ftv2+    raceother:ftv2+  
          0.60858            3.00146           -0.74921  

Degrees of Freedom: 188 Total (i.e. Null);  162 Residual
Null Deviance:	    234.7 
Residual Deviance: 181.3 	AIC: 235.3
```

==============
class: small-code


```r
summary(mod_smaller)
```

```

Call:
glm(formula = low ~ ., family = binomial, data = lowweights)

Deviance Residuals: 
    Min       1Q   Median       3Q      Max  
-1.7038  -0.8068  -0.5008   0.8835   2.2152  

Coefficients:
            Estimate Std. Error z value Pr(>|z|)
(Intercept)  -2.0742     0.4862  -4.266 1.99e-05
age          -0.1973     0.2051  -0.962  0.33602
lwt          -0.4787     0.2165  -2.211  0.02705
raceblack     1.1924     0.5360   2.225  0.02609
raceother     0.7407     0.4617   1.604  0.10869
smoke         0.7555     0.4250   1.778  0.07546
ptlTRUE       1.3438     0.4806   2.796  0.00518
ht            1.9132     0.7207   2.654  0.00794
ui            0.6802     0.4643   1.465  0.14296
ftv1         -0.4364     0.4794  -0.910  0.36268
ftv2+         0.1790     0.4564   0.392  0.69488

(Dispersion parameter for binomial family taken to be 1)

    Null deviance: 234.67  on 188  degrees of freedom
Residual deviance: 195.48  on 178  degrees of freedom
AIC: 217.48

Number of Fisher Scoring iterations: 4
```

The link function in action
===============
class: small-code


```r
plot(predict(mod_full, type = "response"), predict(mod_full, type = "link"))
```

![plot of chunk unnamed-chunk-18](session1-figure/unnamed-chunk-18-1.png)

Predicted versus response
===============
class: small-code

![plot of chunk unnamed-chunk-19](session1-figure/unnamed-chunk-19-1.png)


Familiar diagnostic plots
===============
class: small-code


```r
par(mfrow = c(2, 2))
plot(mod_full)
```

![plot of chunk unnamed-chunk-20](session1-figure/unnamed-chunk-20-1.png)



Global test of interactions
============
class: small-code
Testing whether the model that has race interactions has better explanatory power than that without:


```r
anova(mod_smaller, mod_full, test = "Chisq") 
```

```
Analysis of Deviance Table

Model 1: low ~ age + lwt + race + smoke + ptl + ht + ui + ftv
Model 2: low ~ race * (age + lwt + race + smoke + ptl + ht + ui + ftv)
  Resid. Df Resid. Dev Df Deviance Pr(>Chi)
1       178     195.48                     
2       162     181.31 16   14.162   0.5867
```

This test is suspect when the response is 0/1 binary, and an AIC comparison is probably sounder so long as we think the model fit is ok (ie not too much over-dispersion):


```r
c(AIC(mod_smaller), AIC(mod_full))
```

```
[1] 217.4755 235.3137
```


Successful predictions
==============
class: small-code

```r
predictions <- predict(mod_smaller, type = "response") > 0.5

res <- table(predictions, lowweights$low)
res
```

```
           
predictions   0   1
      FALSE 116  37
      TRUE   14  22
```

```r
sum(diag(res)) / nrow(lowweights)
```

```
[1] 0.7301587
```


Cross-Validation
=================================
class: small-code


```r
TRC <- trainControl(method = "repeatedcv", number = 10, repeats = 10)

mod_cv <- train(low ~ ., method = "glm", family = binomial, 
                trControl = TRC, data = lowweights)

mod_cv$results
```

```
  parameter  Accuracy    Kappa AccuracySD  KappaSD
1      none 0.6891228 0.198898 0.08000614 0.203872
```


Inference with final model
======================

![plot of chunk unnamed-chunk-25](session1-figure/unnamed-chunk-25-1.png)



Specifying a non-canonical link
================================
class: small-code


```r
TRC <- trainControl(method = "repeatedcv", number = 10, repeats = 10)

mod_cv <- train(low ~ ., method = "glm", family = binomial(link = "probit"), 
                trControl = TRC, data = lowweights)

mod_cv$results
```

```
  parameter  Accuracy     Kappa AccuracySD   KappaSD
1      none 0.6926316 0.1992982 0.08696615 0.2130041
```


Three ways to specific binomial
=====================

- Each row a single trial; or
- Two methods where each row represents repeated trials with identical co-variates:
  - response is "proportion successful", with `weights = ` indicating number of trials; or
  - response is a two-column matrix of successes and failures.

See `?glm`.

Over- and under- dispersion
==========================

Binomial, Poisson and Gamma families need a specified scale of variance, which can be checked (ie for "over-dispersion" or "under-dispersion").  Quasi- families are an alternative if this forms a problem.

For an example, with the simplest (and original!) Poisson family data, number of deaths by horse kick:


```r
Bortkiewicz <- rep(0:5, times = c(109,65,22,3,1,0))
mod <- glm(Bortkiewicz ~ 1, family = poisson)
```


================
class: small-code

Residual deviance divided by degrees of freedom should be approximately one.

```r
summary(mod)
```

```

Call:
glm(formula = Bortkiewicz ~ 1, family = poisson)

Deviance Residuals: 
    Min       1Q   Median       3Q      Max  
-1.1045  -1.1045  -1.1045   0.4567   2.8748  

Coefficients:
            Estimate Std. Error z value Pr(>|z|)
(Intercept) -0.49430    0.09053   -5.46 4.77e-08

(Dispersion parameter for poisson family taken to be 1)

    Null deviance: 212.47  on 199  degrees of freedom
Residual deviance: 212.47  on 199  degrees of freedom
AIC: 414.21

Number of Fisher Scoring iterations: 5
```

```r
exp(confint(mod)) # mean number of deaths (discuss why exp()?)
```

```
    2.5 %    97.5 % 
0.5080600 0.7247332 
```

Binomial under-dispersion
==================
class: small-code
It's common to have a response which is a proportion but which is under-dispersed (relative to the Binomial distribution) because it was created by something other than independent binary trials.


```r
mod1 <- glm(PropSelfEmployed2013 ~ PropBachelor2013, family = binomial, data = AreaUnits2013, na.action = "na.omit")
deviance(mod1) /   length(residuals(mod1))  # too small
```

```
[1] 0.06227021
```

```r
summary(mod1)$dispersion # forced to be 1
```

```
[1] 1
```


Quasi-binomial
==========================
class: small-code

The answer is either a beta regression, or (simpler) to relax the scale of the relationship between mean and variance and use a quasi-binomial family.  Now R will estimate dispersion from the data.


```r
mod2 <- glm(PropSelfEmployed2013 ~ PropBachelor2013, family = quasibinomial, data = AreaUnits2013, na.action = "na.omit")

deviance(mod2) /   length(residuals(mod2))
```

```
[1] 0.06227021
```

```r
summary(mod2)$dispersion 
```

```
[1] 0.06533232
```

Quasi-binomial
=============================
This gives us a way of modelling data with non-normal, proportion-like distribution but with smaller variance than binomial trials.  And drawing inferences:

```r
confint(mod1) # too wide
```

```
                       2.5 %    97.5 %
(Intercept)      -2.01558248 -1.515478
PropBachelor2013 -0.08708383  3.835523
```

```r
confint(mod2) # more realistic
```

```
                     2.5 %    97.5 %
(Intercept)      -1.827306 -1.699538
PropBachelor2013  1.390774  2.392544
```

Bootstrap still best for inference
=================
class: small-code


```r
my_func <- function(x, i){
  mod <- glm(PropSelfEmployed2013 ~ PropBachelor2013, family = quasibinomial, na.action = "na.omit",data = x[i, ])
  return(coef(mod)[2])
}
booted <- boot(AreaUnits2013, my_func, R = 499)
boot.ci(booted, type = "perc")
```

```
BOOTSTRAP CONFIDENCE INTERVAL CALCULATIONS
Based on 499 bootstrap replicates

CALL : 
boot.ci(boot.out = booted, type = "perc")

Intervals : 
Level     Percentile     
95%   ( 1.482,  2.328 )  
Calculations and Intervals on Original Scale
```

But in this case the bootstrap confidence interval is pretty much the same as the calculated one (which gives us some confidence in the whole thing).

Sample size implications
=======================
Number of predictors should be less than $m/20$ or at most $m/10$, where $m$ is:

|Type of response variable|Limiting sample size $m$|
|-------------------------|------------------------|
|Continuous               |$n$ (total sample size)  |
|Binary | $min(n_1,n_2)$|
|Ordinal ($k$ categories) | $$n-\frac{1}{n^2}\sum_{i=1}^k{n^3}$$|
|Failure (survival time)| number of failures|

***

> "...it is only a mild oversimplification to say that a good overall strategy is to decide how many degrees of freedom can be 'spent', where they should be spent, and then to spend them."

Frank Harrell

*Regression Modeling Strategies* 

2. Generalized Additive Model
==============================

Definitively introduced by Hastie and Tibshirani (1990).

The Generalized Additive Model introduces non-linearity in the link function between the linear predictor and the conditional mean of the response.  Generalized Additive Models provide a much more flexible addition to this by adding a bunch of splines for the linear predictor.

These days this has become very familiar from scatter plot smoothers, which often use a GAM rather than a simple LOESS smoother when the data gets larger.

================
class: small-code

```r
ggplot(AreaUnits2013, aes(y = PropSelfEmployed2013, x = PropBachelor2013)) +
  geom_smooth() +
  geom_point()
```

```
`geom_smooth()` using method = 'gam'
```

![plot of chunk unnamed-chunk-33](session1-figure/unnamed-chunk-33-1.png)

Difference from the GLM
=================
Instead of:
$$g(E(\mathbf{y}))= \beta_0 + \beta_1 x_1 + \beta_2 x_2 +...+ \beta_p x_p$$

We generalise to:

$$g(E(\mathbf{y}))= \beta_0 + f_1(x_1) + f_2(x_2) +...+ f_3(x_p)$$

Where $f_j$ is usually either a simple linear multiplier or a non-parametric smoothing function.


The variance stays the same:
$${\sigma_y}^2=\phi V(\mathbf{\mu})$$

Smoothing approaches
====================
A number are available.  In the `mgcv` ("Mixed GAM Computation Vehicle") package "are all based one way or another on low rank versions of splines".

The default used by the `s()` function is a low rank isotropic smoother of any number of covariates:

- Rotation of the covariates co-ordinate system won't change the result
- Fewer coefficients than there are data to smooth
- Optimal smoother of any given dimension
- Do not have 'knots' in the conventional sense

See `?smooth.terms`

Smoothing in action
=========================
class: small-code



```r
mod1 <- gam(PropSelfEmployed2013 ~ s(PropBachelor2013), 
               data = AreaUnits2013, family = quasibinomial)
summary(mod1)
```

```

Family: quasibinomial 
Link function: logit 

Formula:
PropSelfEmployed2013 ~ s(PropBachelor2013)

Parametric coefficients:
            Estimate Std. Error t value Pr(>|t|)
(Intercept) -1.57116    0.01532  -102.6   <2e-16

Approximate significance of smooth terms:
                      edf Ref.df     F p-value
s(PropBachelor2013) 7.726  8.596 21.73  <2e-16

R-sq.(adj) =  0.0924   Deviance explained = 10.3%
GCV = 0.058078  Scale est. = 0.061134  n = 1863
```

================

```r
plot(mod1)
```

![plot of chunk unnamed-chunk-35](session1-figure/unnamed-chunk-35-1.png)


With no smoothing, is just a GLM
=========================
class: small-code


```r
mod2  <- gam(PropSelfEmployed2013 ~ PropBachelor2013, 
               data = AreaUnits2013, family = quasibinomial)
summary(mod2) # recognise the scale estimate from earlier?
```

```

Family: quasibinomial 
Link function: logit 

Formula:
PropSelfEmployed2013 ~ PropBachelor2013

Parametric coefficients:
                 Estimate Std. Error t value Pr(>|t|)
(Intercept)       -1.7633     0.0326 -54.084  < 2e-16
PropBachelor2013   1.8929     0.2556   7.405 1.97e-13


R-sq.(adj) =  0.0264   Deviance explained = 2.94%
GCV = 0.062404  Scale est. = 0.065368  n = 1863
```


s() will allocate degrees of freedom
=========================
class: small-code


```r
mod3  <- gam(PropSelfEmployed2013 ~ MeanBedrooms2013 + s(PropPrivateDwellings2013)
               + s(PropBachelor2013) + s(PropOld2013) + s(PropEuropean2013), 
               data = AreaUnits2013, family = quasibinomial)
summary(mod3) # recognise the scale estimate from earlier?
```

```

Family: quasibinomial 
Link function: logit 

Formula:
PropSelfEmployed2013 ~ MeanBedrooms2013 + s(PropPrivateDwellings2013) + 
    s(PropBachelor2013) + s(PropOld2013) + s(PropEuropean2013)

Parametric coefficients:
                 Estimate Std. Error t value Pr(>|t|)
(Intercept)       -3.4803     0.1219  -28.55   <2e-16
MeanBedrooms2013   0.5859     0.0382   15.34   <2e-16

Approximate significance of smooth terms:
                              edf Ref.df     F  p-value
s(PropPrivateDwellings2013) 7.569  8.488 29.23  < 2e-16
s(PropBachelor2013)         4.952  6.093 11.80 3.96e-13
s(PropOld2013)              6.730  7.879 12.43  < 2e-16
s(PropEuropean2013)         5.746  6.918 84.04  < 2e-16

R-sq.(adj) =  0.503   Deviance explained = 52.5%
GCV = 0.031342  Scale est. = 0.032536  n = 1861
```

==============

```r
par(mfrow = c(2, 2))
plot(mod3, shade = TRUE, seWithMean = TRUE)
```

![plot of chunk unnamed-chunk-38](session1-figure/unnamed-chunk-38-1.png)


With curved interactions
=====================
class: small-code


```r
mod4  <- gam(PropSelfEmployed2013 ~ MeanBedrooms2013 + s(PropPrivateDwellings2013)
               + s(PropBachelor2013) + s(PropOld2013, PropEuropean2013), 
               data = AreaUnits2013, family = quasibinomial)
summary(mod4)
```

```

Family: quasibinomial 
Link function: logit 

Formula:
PropSelfEmployed2013 ~ MeanBedrooms2013 + s(PropPrivateDwellings2013) + 
    s(PropBachelor2013) + s(PropOld2013, PropEuropean2013)

Parametric coefficients:
                 Estimate Std. Error t value Pr(>|t|)
(Intercept)      -3.47824    0.12066  -28.83   <2e-16
MeanBedrooms2013  0.58479    0.03782   15.46   <2e-16

Approximate significance of smooth terms:
                                   edf Ref.df     F  p-value
s(PropPrivateDwellings2013)      7.580  8.495 28.02  < 2e-16
s(PropBachelor2013)              5.101  6.256 12.73 1.87e-14
s(PropOld2013,PropEuropean2013) 22.654 26.713 26.62  < 2e-16

R-sq.(adj) =  0.515   Deviance explained = 54.5%
GCV = 0.030426  Scale est. = 0.031262  n = 1861
```

Plotting curved interactions
=======================

```r
plot(mod4, pages = 1, shade = TRUE, all.terms = TRUE, seWithMean = TRUE)
```

![plot of chunk unnamed-chunk-40](session1-figure/unnamed-chunk-40-1.png)

Alternative plot of curved interaction
======================

```r
plot(mod4, select = 3, pers = TRUE, theta = -45)
```

![plot of chunk unnamed-chunk-41](session1-figure/unnamed-chunk-41-1.png)

As part of a modelling strategy
===================
class: small-code

Prone to overfitting so  we may want to specify in advance how many effective degrees of freedom we allow for each variable.  Basing this on the Spearman multiple correlation between $rank(x)$, $rank(x^2)$ and $y$ can be effective.  

Example in a later lab session, but as a starter:


```r
library(Hmisc)
with(AreaUnits2013, spearman2(PropSelfEmployed2013 ~ MeanBedrooms2013 + PropPrivateDwellings2013 + PropBachelor2013))
```

```

Spearman rho^2    Response variable:PropSelfEmployed2013

                          rho2      F df1  df2 P Adjusted rho2    n
MeanBedrooms2013         0.251 624.64   1 1862 0         0.251 1864
PropPrivateDwellings2013 0.010  19.08   1 1863 0         0.010 1865
PropBachelor2013         0.093 191.40   1 1861 0         0.093 1863
```

And we could then use the `k = ` argument to `s()` to give more effective degrees of freedom to the variables with higher rho2.

Cross-validation
=======================
class: small-code

Unfortunately the `train` function in `caret` doesn't let you specify a `gam` formula so we often need another way to validate a model.  GAMs are prone to over-fitting so some resampling-based validation is important.

```r
fulldata <- AreaUnits2013 %>%
  select(PropSelfEmployed2013, MeanBedrooms2013, PropPrivateDwellings2013,
         PropBachelor2013, PropOld2013, PropEuropean2013)

my_function <- function(x, i){
  # fit model to resample:
  mod  <- gam(PropSelfEmployed2013 ~ MeanBedrooms2013 + s(PropPrivateDwellings2013)
               + s(PropBachelor2013) + s(PropOld2013) + s(PropEuropean2013), 
               data = x[i, ], family = quasibinomial)
  # use that model to predict the full original sample:
  goodness <- postResample(predict(mod, type = "response", newdata = fulldata), 
                           obs = fulldata$PropSelfEmployed2013)
  return(goodness)
}
booted <- boot(fulldata, statistic = my_function, R = 199)
```

=====================
class: small-code


```r
# display confidence interval for the second bootstrapped parameter (R2)
boot.ci(booted, index = 2, type = "norm")
```

```
BOOTSTRAP CONFIDENCE INTERVAL CALCULATIONS
Based on 199 bootstrap replicates

CALL : 
boot.ci(boot.out = booted, type = "norm", index = 2)

Intervals : 
Level      Normal        
95%   ( 0.4939,  0.5641 )  
Calculations and Intervals on Original Scale
```

Credibility intervals and inference
========================

`plot.gam()` shows credibility intervals of the contribution of individual smoothed terms to the scale of the linear predictor.  Converting this into a simple number for inference is a little complex - you will need to think carefully through what you actually want to infer.

Prediction intervals for any given are provided by `predict()`, see this [Q&A on Cross-Validated](http://stats.stackexchange.com/questions/33327/confidence-interval-for-gam-model).

For more complex cases, simulation of some sort usually needed.  See this impressive [blog post by Gavin Simpson](http://www.fromthebottomoftheheap.net/2011/06/12/additive-modelling-and-the-hadcrut3v-global-mean-temperature-series/) for a possible example.


Use cases
=========

- modelling that involves any kind of interpolation
- any kind of predictive analytics (including when prediction is needed to fix nuisance absences eg imputation)
- pick up atheoretical non-linearities and still show significant evidence of relationship
- control for non-linear nuisance factors like geo-spatial correlation


Other bonuses of `mgcv`
===============

Extends GLM out to some distributions not in `stats::glm`.  For example (not comprehensive):

- `negbin` - an alternative to quasipoisson for overdispersed counts
- `Tweedie` - variance of the response proportionate to $\mu^p$ where $p$ is in $(1, 2)$
- `ocat` for ordered categorical data
- `betar` - an alternative to quasibinomial for under or over dispersed proportions
- `ziP` - zero-inflated Poisson data
- `multinom` - multinomial logistic regression with unordered categorical response

See `?family.mgcv

When the going gets bigger and tougher:
==================

In `mgcv`
- `bam` - fits a GAM (including any GLM) to a very large data set
- `gamm` - generalized additive mixed models (but see also `lme4` or `nlme`, coming up later in this course)


In H2O
- `h2o.glm` - can fit a GLM to arbitrarily large data sets


References and more info
=========================
- Wikipedia
- the `glm` and `mgcv` helpfiles
- Cross-Validated
- Mcullagh and Nelder (1989) *Generalized Linear Models*, second edition
- Hastie and Tibshirani (1990) *Generalized Additive Models*
- Frank Harrell (2001) *Regression Modeling Strategies*
- Wood (2006) *Generalized Additive Models: An Introduction with R* 
- Wood (2011) Fast stable restricted maximum likelihood and marginal likelihood estimation of
  semiparametric generalized linear models. *Journal of the Royal Statistical Society* (B) 73(1):3-36
- Venables and Ripley (2002), *Modern Applied Statistics with S*, fourth edition

